import java.io.*;
import java.util.*;

class Main {
    public void run() throws IOException{
        // BufferedReaderの定義
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // 一行読み取りtにIntにキャストし，tに代入する
        int t = Integer.parseInt(br.readLine());
        for(int i = 0; i < t; i++){
            // 一行読み取り，それを空白で区切り配列splitLineに代入する
            String[] splitLine = br.readLine().split(" ");

            // 各splitlineの要素をIntにキャストしつつ，代入する
            int a = Integer.parseInt(splitLine[0]);
            int b = Integer.parseInt(splitLine[1]);
            int c = Integer.parseInt(splitLine[2]);

            System.out.printf("Case #%d:\n", i + 1);

            // 寺子さんが間に合った時
            if(a >= b + c){
                System.out.println(b + c);
            } else{ // 間に合わなかった時
                System.out.println("NG");
            }
        }
    }

    public static void main(String... args) throws IOException{
        new Main().run();
    }
}

