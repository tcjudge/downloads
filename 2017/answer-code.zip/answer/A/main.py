#!/usr/bin/python
# coding: utf-8

def solve():
    # それぞれの入力の読み込み
    limit, start, cost = map(int, raw_input().split(" "))
    # 三項演算子による出力 以下と等価
    print start+cost if limit >= start+cost else "NG"
    """
    if limit >= start+cost:
        print start+cost
    else:
        print "NG"
    """

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
