// 入出力関係
#include<stdio.h>

int main(void) {
    // 授業開始時間
    int S;
    // 家を出る時間
    int O;
    // 家から教室までかかる時間
    int C;
    // 着いた時間
    int time;
    // テストケース数
    int T;
    // カウンタ変数
    int i;
    
    // テストケース数の入力
    scanf("%d", &T);
    
    // テストケース回,処理を繰り返す
    for(i=1; i<=T; i++) {
        // ケース数を出力
        printf("Case #%d:\n", i);
        
        // 入力
        scanf("%d %d %d", &S, &O, &C);
        
        // 着いた時間を計算する
        time = O+C;
        
        // 授業開始時間を過ぎていた場合
        if(time > S) printf("NG\n");
        // 授業に間に合った場合,着いた時間を出力
        else printf("%d\n", time);
    }

    return 0;
}

