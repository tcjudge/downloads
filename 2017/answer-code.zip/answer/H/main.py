#!/usr/bin/python
# coding: utf-8

INF = float("inf")

# ワーシャルフロイド法による距離の計算
def warshall_floyd(graph, apex):
    for k in xrange(apex):
        for i in xrange(apex):
            for j in xrange(apex):
                graph[i][j] = min(graph[i][j], graph[i][k]+graph[k][j])

def solve():
    apex, side = map(int, raw_input().split())
    start, sword, goal = map(int, raw_input().split())

    graph = [[INF for i in xrange(apex)] for j in xrange(apex)]
    for _ in xrange(side):
        x, y, distance = map(int, raw_input().split())
        graph[x][y] = distance
        graph[y][x] = distance

    warshall_floyd(graph, apex)
    print graph[start][sword] + graph[sword][goal]

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()

