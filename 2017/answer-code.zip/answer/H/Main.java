import java.io.*;
import java.util.*;
class Main {
    Scanner sc;
    final int INF = 100000000;  // 極大値
    int[][] d;      // 最短値を格納するための行列
    /**
     * ワーシャルフロイド法により最短値を計算
     */
    void warshallFloyd (int V) {
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                for (int k = 0; k < V; k++) {
                    // iを経由した方が値が小さくなるなら更新
                    d[j][k] = Math.min(d[j][k], d[j][i] + d[i][k]);
                }
            }
        }
    }
    int solve(int V, int E, int s, int m, int t) {
        // 初期化
        d = new int[V][V];
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (i == j) {
                    // 同じ頂点への最短値は0
                    d[i][j] = 0;
                } else {
                    // それ以外は極大値で初期化
                    d[i][j] = INF;
                }
            }
        }
        // 入力
        for (int i = 0; i < E; i++) {
            int v = sc.nextInt();
            int u = sc.nextInt();
            int c = sc.nextInt();
            d[v][u] = c;
            d[u][v] = c;
        }
        warshallFloyd(V);
        return d[s][m] + d[m][t];
    }
    void run() {
        sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int i = 1; i <= T; i++) {
            int V = sc.nextInt();
            int E = sc.nextInt();
            int s = sc.nextInt();
            int m = sc.nextInt();
            int t = sc.nextInt();
            System.out.printf("Case #%d:\n", i);
            System.out.println(solve(V, E, s, m, t));

        }
    }
    public static void main(String[] args) {
        new Main().run();
    }
}
