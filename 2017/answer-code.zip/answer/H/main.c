#include<stdio.h>
// 最大の辺の数
#define MAX_V 101

// 最大のコスト
#define MAX_VALUE 101

// costテーブル
int cost[MAX_V][MAX_V] = {};

// 入力された辺の数
int V;

// min関数の定義
int min(int a, int b){
    if(a <= b){
        return a;
    }
    return b;
}

// ワーシャルフロイド法により最短距離のコストを求める
void warshall_floyd(){
    for(int k = 0; k < V; k++){
        for(int i = 0; i < V; i++){
            for(int j = 0; j < V; j++){
                cost[i][j] = min(cost[i][j], cost[i][k] + cost[k][j]);
            }
        }
    }
}

int main(void){
    int T;
    scanf("%d", &T);

    for(int n = 0;n < T; n++){
        // costテーブルを最大の値で初期化する
        for(int i = 0; i < MAX_V; i++){
            for(int j = 0; j < MAX_V; j++){
                cost[i][j] = MAX_VALUE;
            }
        }

        int e;
        scanf("%d %d", &V, &e);

        int s, m, t;
        scanf("%d %d %d", &s, &m, &t);

        // 入力を受け取り，それをcostテーブルに反映させる
        for(int i = 0; i < e; i++){
            int v_, u_, e_;
            scanf("%d %d %d", &v_, &u_, &e_);

            // 無向グラフなので両方に同じコストを代入しておく
            cost[v_][u_] = e_;
            cost[u_][v_] = e_;
        }

        // 関数を呼び，コストを求める
        warshall_floyd();

        int sum_cost = 0;

        // sからmまでのコストとmからtまでのコストを足した値が答えとなる
        sum_cost += cost[s][m];
        sum_cost += cost[m][t];
        printf("Case #%d:\n", n+1);
        printf("%d\n", sum_cost);

    }
}
