#include <iostream>
#include <vector>
using namespace std;
typedef vector<vector<int> > Matrix;    // vectorによる二重配列
const int INF = 100000000;      // 極大値
Matrix d;   // 最短値を格納するための行列
/**
 * ワーシャルフロイド法により最短値を計算
 */
void warshallFloyd(int V) {
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            for (int k = 0; k < V; k++) {
                // iを経由した方が値が小さいなら更新
                d[j][k] = min(d[j][k], d[j][i] + d[i][k]);
            }
        }
    }
}
int solve(int V, int E, int s, int m, int t) {
    // init
    d = Matrix(V, vector<int>(V, INF));
    for (int i = 0; i < V; i++) {
        d[i][i] = 0;
    }
    // input
    for (int i = 0; i < E; i++) {
        int v, u, c;
        cin >> v >> u >> c;
        d[v][u] = d[u][v] = c;
    }
    warshallFloyd(V);
    return d[s][m] + d[m][t];
}
int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        int V, E;
        cin >> V >> E;
        int s, m, t;
        cin >> s >> m >> t;
        cout << "Case #" << i << ":" << endl;
        cout << solve(V, E, s, m, t) << endl;
    }
}
