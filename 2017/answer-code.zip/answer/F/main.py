#!/usr/bin/python
#coding: utf-8

ZOMBI = "2"
PERSON = "1"

def is_person(element):
    return element == PERSON

def is_zombi(element):
    return element == ZOMBI

# 生存者の確認
def exist_survivor(board):
    for raw in board:
        for element in raw:
            if is_person(element):
                return True
    return False

# 感染者座標のリストを返す
def fetch_zombis(board):
    return [(i, j) for j, raw in enumerate(board) for i, element in enumerate(raw) if is_zombi(element)]

# 感染させる（1ターン）
def pandemic(board, zombi_list):
    dxy = [0, 1, 0, -1, 1, 1, -1, -1, 0]
    new_zombi_list = list()
    for x, y in zombi_list:
        # 8近傍探索
        # 感染者の8近傍に人がいれば次のターンのゾンビとする
        for i in xrange(8):
            target_x = x+dxy[i]
            target_y = y+dxy[i+1]
            target = board[target_y][target_x]
            if is_person(target):
                new_zombi_list.append((target_x, target_y))
                board[target_y][target_x] = ZOMBI
    return new_zombi_list

def simulate(board):
    days = 0
    zombi_list = fetch_zombis(board)
    while True:
        zombi_list = pandemic(board, zombi_list)
        # 新たな感染者がいない
        if len(zombi_list) == 0:
            break
        days += 1
    return days

def solve():
    width, height = map(int, raw_input().split())
    # 余白
    width += 2
    height += 2
    board = []
    # 盤面の読み込み 余白は None とする
    board.append([None for _ in xrange(width)])
    for _ in xrange(height-2):
        board.append([None]+raw_input().split()+[None])
    board.append([None for _ in xrange(width)])

    days = simulate(board)
    # 生存者がいる場合はALIVE
    if exist_survivor(board):
        print "ALIVE"
        return
    print days

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
