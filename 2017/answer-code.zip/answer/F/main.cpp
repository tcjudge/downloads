#include <iostream>
#include <vector>
#include <cstdlib>
#include <utility>
using namespace std;

int w,h;

// (x, y)マスの感染者の8近傍を感染させる関数
// fieldは，入力されたマス目．これを更新していく．
pair<vector<pair<int, int>>, int> infect(vector<vector<int>> &field, const int x, const int y){
    // 現在のマス目から8近傍を探索するための配列dx, dyを定義
    static int dx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    static int dy[] = {0, -1, -1, -1, 0, 1, 1, 1};
    int sum = 0; // 感染させた数
    vector<pair<int, int>> new_infections; // 新たな感染者のマス目(x, y)を追加する

    for(int i = 0; i < 8; ++i){
        const int next_x = x + dx[i];
        const int next_y = y + dy[i];
        if(next_x >= w || next_x < 0) continue; // 領域外ではないかチェック
        if(next_y >= h || next_y < 0) continue; // 領域外ではないかチェック

        // 未感染者が，感染者の8近傍にいる
        if(field[next_x][next_y] == 1){
            field[next_x][next_y] = 2;
            sum++; // 感染者の数を+1
            new_infections.push_back(make_pair(next_x, next_y)); // 新たな感染者のマス目を追加
        }
    }

    // 新たな感染者のマス目情報をreturn
    return make_pair(new_infections, sum);
}

int main(){
    int T; cin >> T;

    for(int nth = 1; nth <= T; ++nth){
        cin >> w >> h;
        int person = 0; // フィールドにいる人数（感染者と未感染者の数を保持）

        vector<vector<int>> field(w, vector<int>(h)); // フィールドの情報を保持
        vector<pair<int, int>> infections; // 感染者のいるマス目

        // 入力と感染者のいるマス目情報をそれぞれ更新
        for(int y = 0; y < h; ++y){
            for(int x = 0; x < w; ++x){
                cin >> field[x][y];
                if(field[x][y] != 0) person++;
                if(field[x][y] == 2) infections.push_back(make_pair(x, y));
            }
        }

        int infected = infections.size(); // 現在の感染者の数を保持．
        int pre_infected; // 一つ前の状態の感染者の数を保持
        int turn = 0; // 感染に要した日数
        int start = 0; // チェックする感染者配列（infections）のスタート位置を保持

        if(infected != person && person != person - infected){
            while(true){
                pre_infected = infected;
                const int size = infections.size();
                // 感染させる
                for(int i = start; i < size; ++i){
                    pair<vector<pair<int, int>>, int> ret = infect(field, infections[i].first, infections[i].second);
                    // 新しい感染者を増やす
                    for(const auto& new_infection : ret.first){
                        infections.push_back(new_infection);
                    }
                    infected += ret.second; // 感染者の数を増やす
                }

                start = size; // 次に調べるインデックスを保持
                turn++; // 日数を増やす

                // 現在の感染者数と一つ前の状態の感染者数の数が等しい（つまり，これ以上感染はしないかどうか）
                // もしくは，感染済みの人の数とフィールドのにいる人数が等しい（つまり，全員感染したかどうか）
                if(infected == pre_infected || infected == person) break;
            }
        }

        cout << "Case #" << nth << ":\n";
        if(infected != person) cout << "ALIVE\n"; // 全員感染していなければ
        else cout << turn << endl;
    }

    return EXIT_SUCCESS;
}
