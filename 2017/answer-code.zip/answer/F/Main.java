import java.util.Scanner;

public class Main {
	static int [][] c = new int[2000][2000];
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		int t = scan.nextInt();
		for(int m=1;m<=t;m++){
			int a = scan.nextInt();
			int b = scan.nextInt();
			int k = 1000;
			boolean flag = true;
			//２次元配列の初期化・値の入力
			c = new int[b+2][a+2];
			for(int i=0;i<b+2;i++){
				for(int j=0;j<a+2;j++){
					c[i][j]=0;
				}
			}
			int count=0;
			for(int i=1;i<b+1;i++){
				for(int j=1;j<a+1;j++){
					c[i][j] = scan.nextInt();
				}
			}
			//全てのマスに対してチェックを行う
			for(int i=1;i<b+1;i++){
				for(int j=1;j<a+1;j++){
					if(c[i][j]==2){
						pandemic(i,j,k);
					}
				}
			}
			//もし非感染者が残っているなら”ALIVE"を出力
			//そうでないなら,全てのマスの中で一番数値の大きい(一番時間がかかった)ものを出力する
			for(int i=1;i<b+1;i++){
				for(int j=1;j<a+1;j++){
					if(c[i][j]==1){
						flag=false;
					}else if(c[i][j]>count){
						count=c[i][j];
					}
				}
			}
			System.out.println("Case #"+m+":");

			if(flag){
				System.out.println(count-1000);
			}else{
				System.out.println("ALIVE");
			}
		}
	}
	//引数で渡した場所の8近傍を再帰的に探索する
	static public void pandemic(int i,int j,int k){
		c[i][j]=k;
		k++;
		if(c[i+1][j]==1||c[i+1][j]>k) pandemic(i+1,j,k);
		if(c[i+1][j+1]==1||c[i+1][j+1]>k) pandemic(i+1,j+1,k);
		if(c[i][j+1]==1||c[i][j+1]>k) pandemic(i,j+1,k);
		if(c[i-1][j+1]==1||c[i-1][j+1]>k) pandemic(i-1,j+1,k);
		if(c[i-1][j]==1||c[i-1][j]>k) pandemic(i-1,j,k);
		if(c[i-1][j-1]==1||c[i-1][j-1]>k) pandemic(i-1,j-1,k);
		if(c[i][j-1]==1||c[i][j-1]>k) pandemic(i,j-1,k);
		if(c[i+1][j-1]==1||c[i+1][j-1]>k) pandemic(i+1,j-1,k);
	}
}
