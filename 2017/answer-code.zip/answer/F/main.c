#include<stdio.h>

// 0:壁 1:人 2:ゾンビ 3:場外

// マップ管理用配列
int map[201][201];

// ゾンビ管理用配列
int zonbisxy[201][201];

// 8近傍探索用配列
int dx[] = {-1, 0, 1, 1, 1, 0, -1, -1};
int dy[] = {1, 1, 1, 0, -1, -1, -1, 0};

// ターンをカウントする変数
int count = 0;

// 人が生きているかを確認する
// 0 -> 人がもういない
// 1 -> 人が生存している
// 2 -> 人が生存しているが感染することが不可能である
int check_people_arive(int h, int w){
    for(int i = 0; i < h; i++){
        for(int j = 0; j < w; j++){
            if(map[i][j] == 1){
                // 周りが全て壁かどうかをチェックする
                int flag = 1;
                for(int l = 0; l < 8; l++){
                    if(i + dy[l] >= 0 || j + dx[l] >= 0){
                        if(map[i + dy[l]][j + dx[l]] != 0 || map[i + dy[l]][j + dx[l]] != 3){
                            flag = 0;
                        }
                    }
                }
                if(flag)
                    return 2;
                return 1;
            }
        }
    }
    return 0;
}



// ゾンビを発見したら，8近傍を見て生存者を感染させる．
// そして全ての処理が終わったらカウントを1進める
void pandemic(int i, int j){
    // 場外もしくは，壁の場合
    if(map[i][j] == 0 || map[i][j] == 3)
        return;

    // 8近傍探索をし，人の状態をゾンビに更新する．
    for(int l = 0; l < 8; l++){
        if(i + dy[l] >= 0 || j + dx[l] >=0){
            if(map[i + dy[l]][j + dx[l]] == 1){
                map[i + dy[l]][j + dx[l]] = 2;
            }
        }
    }
}

int main(void){
    int t;
    scanf("%d", &t);
    for (int m = 0; m < t; m++){
        count = 0;

        // 幅と高さの取得
        int w, h;
        scanf("%d %d", &w, &h);


        // 2次元配列にマップの情報を格納する
        int tmp;
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                scanf("%d", &tmp);
                map[i][j] = tmp;
            }
        }

        // 場外を関係ない数字(3)で埋める
        for(int i = h;i < 201;i++){
            for(int j = w; j < 201; j++){
                map[i][j] = 3;
            }
        }

        // ゾンビ管理配列を初期化する
        for(int i = 0;i < 201;i++){
            for(int j = 0;j < 201;j++){
                zonbisxy[i][j] = 0;
            }
        }


        int zonbi_count = 0;
        while(1){
            // 生存している人の状態をもらってくる
            int check_result = check_people_arive(h, w);

            // 生存者が誰も居ない場合，ターン数を出力して終了する
            if(check_result == 0){
                printf("Case #%d:\n", m+1);
                printf("%d\n", count);
                break;
            }

            // 生存者が壁に覆われており絶対に感染しない場合，ALIVEを出力して終了する
            else if(check_result == 2){
                printf("Case #%d:\n", m+1);
                printf("ALIVE\n");
                break;
            }


            int tmp_count = 0;
            // ゾンビの個数を管理
            for(int i = 0; i < h; i++){
                for(int j = 0; j < w; j++){
                    if(map[i][j] == 2){
                        zonbisxy[i][j] = 1;
                        tmp_count++;
                    }
                }
            }

            // ゾンビが以前のターンより増えている場合，ゾンビの数を更新する
            if(zonbi_count < tmp_count){
                zonbi_count = tmp_count;
            } else { // ゾンビが増えなかった場合，ALIVEを出力して終了する
                printf("Case #%d:\n", m+1);
                printf("ALIVE\n");
                break;
            }

            // 現在のゾンビのいる座標の周りを感染させる．(感染して増えたゾンビは次のターンにpandemicに参加する)
            for(int i = 0; i < h; i++){
                for(int j = 0; j < w; j++){
                    if(zonbisxy[i][j] == 1){
                        pandemic(i, j);
                    }
                }
            }
            count++;
        }

    }


    return 0;
}

