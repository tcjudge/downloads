import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

// エッジ
// あるノードの隣接ノードとそのノードに行くのに要する時間を保持するクラス
class Edge extends Object{
    Integer to, cost;

    Edge(Integer to_, Integer cost_){
        to = to_;
        cost = cost_;
    }

}

// 次のノードと，スタートノードからそこに行くのにかかる時間を保持するクラス
class Pair extends Object{
    Integer to, cost;

    Pair(Integer to_, Integer cost_){
        to = to_;
        cost = cost_;
    }
}

// Comparatorインタフェースの実装
// 時間（cost）を小さいものから取れるように，compareメソッドをオーバーライドする
class ComparatorForDijkstra implements Comparator<Pair>{
    @Override
    public int compare(Pair p1, Pair p2){
        int cmp = p1.cost.compareTo(p2.cost);
        if(cmp < 0){
            return -1;
        }else if(cmp > 0){
            return 1;
        }else{
            return 0;
        }
    }
}

public class Main extends Object{
    Integer numOfVertices, numOfEdges;

    ArrayList<ArrayList<Edge>> makeAdjList(Scanner cin){
        ArrayList<ArrayList<Edge>> adjList = new ArrayList<ArrayList<Edge>>();

        // 隣接リストの初期化
        for(int i = 0; i < numOfVertices; ++i){
            adjList.add(new ArrayList<Edge>());
        }

        for(Integer i = 0; i < numOfEdges; ++i){
            Integer a = cin.nextInt();
            Integer b = cin.nextInt();
            Integer c = cin.nextInt();

            adjList.get(a).add(new Edge(b, c));
            adjList.get(b).add(new Edge(a, c));
        }

        return adjList;
    }

    int[] dijkstra(Integer start, ArrayList<ArrayList<Edge>> adjList){
        // 優先順位付きキュー
        // costが小さいものから順に取れるようにする
        PriorityQueue<Pair> q = new PriorityQueue<Pair>(new ComparatorForDijkstra());

        // スタート地点から他の頂点までの最短距離を入れる配列を用意する
        int[] d = new int[numOfVertices];

        // 初期化
        for(int i = 0; i < numOfVertices; ++i){
            d[i] = Integer.MAX_VALUE;
        }
        d[start] = 0;
        q.add(new Pair(start, 0));

        while(true){
            Pair p = q.poll();
            if(p == null) break;

            final int currentCost = p.cost;
            final int currentVertex = p.to;

            // すでに最短時間が格納されているならばcontinue
            if(d[currentVertex] < currentCost) continue;

            for(Edge neighbor : adjList.get(currentVertex)){
                final int nextCost = neighbor.cost;
                final int nextVertex = neighbor.to;
                if(d[nextVertex] > d[currentVertex] + nextCost){
                    //d.add(nextVertex, d.get(currentVertex) + nextCost);
                    d[nextVertex] = d[currentVertex] + nextCost;
                    q.add(new Pair(nextVertex, nextCost));
                }
            }
        }

        return d;
    }

    void run(){
        Scanner cin = new Scanner(System.in);
        Integer T = cin.nextInt();

        for(int i = 1; i <= T; ++i){
            numOfVertices = cin.nextInt();
            numOfEdges = cin.nextInt();
            Integer s, m, t;
            s = cin.nextInt();
            m = cin.nextInt();
            t = cin.nextInt();
            ArrayList<ArrayList<Edge>> adjList = makeAdjList(cin);
            int[] d = dijkstra(m, adjList);

            System.out.println("Case #" + i + ":");
            System.out.println(d[s] + d[t]);
        }
    }

    public static void main(String[] args){
        new Main().run();
    }
}
