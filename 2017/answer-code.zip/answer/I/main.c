#include<stdio.h>
// 最大の辺の数
#define MAX_V 20001

// ノードの最大値
#define MAX_VALUE 214748364

int cost[MAX_V][MAX_V] = {};
int d[MAX_V] = {0};
int used[MAX_V] = {0};
int V;

// min関数
int min(int a, int b){
    if(a <= b){
        return a;
    }
    return b;
}

// ダイクストラ法
void dijkstra(int s){

    // 各変数の初期化
    for(int i = 0; i < V; i++){
        used[i] = 0;
    }
    for(int i = -1; i < V; i++){
        d[i] = MAX_VALUE;
    }
    d[s] = 0;

    // メイン処理
    while(1){
        int v = -1;
        for(int u = 0; u < V; u++){
            if(!used[u] && (v == -1 || d[u] < d[v])) v = u;
        }
        if(v == -1) break;
        used[v] = 1;

        for(int u = 0; u < V; u++){
            d[u] = min(d[u], d[v] + cost[v][u]);
        }
    }
}

int main(void){
    int t;
    scanf("%d\n", &t);

    for(int n = 0; n < t; n++){
        // コストを全てMAX_VALUEにしておく
        for(int i = 0; i < MAX_V; i++){
            for(int j = 0; j < MAX_V; j++){
                cost[i][j] = MAX_VALUE;
            }
        }

        int e;
        scanf("%d %d", &V, &e);

        int s, m, t;
        scanf("%d %d %d", &s, &m, &t);

        for(int i = 0; i < e; i++){
            int v_, u_, e_;
            scanf("%d %d %d", &v_, &u_, &e_);

            // 無向グラフなので，両方にコストを追加しておく
            cost[v_][u_] = e_;
            cost[u_][v_] = e_;
        }

        // ダイクストラ法の実行
        dijkstra(m);
        printf("Case #%d:\n", n+1);
        printf("%d\n", d[s] + d[t]);
    }
}
