#!/usr/bin/python
# coding: utf-8
import heapq

INF = float("inf")

# nodeの情報を持つクラス
class node_info:
    destination = int()
    distance = int()
    def __init__(self, destination, distance):
        self.destination = destination
        self.distance = distance

def renewal(distance, queue, start, destination, cost):
    distance[destination] = distance[start] + cost
    heapq.heappush(queue, (distance[destination], destination))

# ダイクストラ法による距離の計算
def dijkstra(graph, distance, apex, sword, start, goal):
    distance[sword] = 0
    nodes = [sword]
    queue = [(0, sword)]
    while not len(queue) == 0:
        cost, node = heapq.heappop(queue)
        if distance[node] < cost:
            continue
        for d in graph[node]:
            if distance[d.destination] <= (distance[node]+d.distance):
                continue
            renewal(distance, queue, node, d.destination, d.distance)

def solve():
    apex, side = map(int, raw_input().split())
    start, sword, goal = map(int, raw_input().split())

    graph = dict()
    for _ in xrange(side):
        x, y, distance = map(int, raw_input().split())
        if not x in graph:
            graph[x] = list()
        if not y in graph:
            graph[y] = list()
        graph[x].append(node_info(y, distance))
        graph[y].append(node_info(x, distance))
    distance = [INF for _ in xrange(apex)]
    dijkstra(graph, distance, apex, sword, start, goal)

    print distance[start] + distance[goal]

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()

