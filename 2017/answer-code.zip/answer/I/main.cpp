#include <iostream>
#include <vector>
#include <cstdlib>
#include <queue>
#include <utility>
#include <climits>
using namespace std;

// エッジ
struct edge{
    int to; // 行き先
    int cost; // 要する時間
    edge(const int to_, const int cost_):to(to_), cost(cost_){} // コンストラクタ
};

using P = pair<int, int>; // first: コスト（つまり，時間）, second: vertex（頂点）
using Graph = vector<vector<edge>>; // グラフ

// ダイクストラ法
vector<int> dijkstra(const Graph& G, const int s){
    vector<int> d(G.size(), INT_MAX); // 各頂点への最小時間を格納する動的配列
    priority_queue<P, vector<P>, greater<P>> q; // コストを昇順にソートする
    q.push(make_pair(0, s)); // 時間を0とスタート地点をqueueに追加する
    d[s] = 0; // スタート地点へのコストを0にする

    while(!q.empty()){
        const int current_cost = q.top().first;
        const int current_v = q.top().second;
        q.pop();
        if(d[current_v] < current_cost) continue;

        for(const auto& e : G[current_v]){
            if(d[e.to] > d[current_v] + e.cost){
                d[e.to] = d[current_v] + e.cost;
                q.push(make_pair(d[e.to], e.to));
            }
        }
    }

    return d;
}

int main(){
    int T; cin >> T;
    for(int nth = 1; nth <= T; ++nth){
        int num_of_vertices, num_of_edges; cin >> num_of_vertices >> num_of_edges;
        int s, m, t; cin >> s >> m >> t;

        /*****グラフを生成*****/
        Graph G(num_of_vertices);
        for(int i = 0; i < num_of_edges; ++i){
            int a, b, c; 
            cin >> a >> b >> c;

            G[a].emplace_back(edge(b, c));
            G[b].emplace_back(edge(a, c));
        }
        /*****グラフ生成終わり****/

        vector<int> d = dijkstra(G, m);

        cout << "Case #" << nth << ":\n";
        cout << d[s] + d[t] << endl; // mからsへの最小時間とmからtへの最小時間を足す
    }

    return EXIT_SUCCESS;
}
