#include <iostream>
#include <vector>
#include <cmath>    // sqrt()を利用
using namespace std;
const int MAX = 46;         // Nの最大値
vector<int> fibonacci;      // フィボナッチ数列
vector<int> sossunachi;     // ソスナッチ数列
/**
 * 素数判定
 */
bool is_prime(int num) {
    for (int i = 2; i < (int)sqrt(num) + 1; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}
/**
 * フィボナッチ数列とソスナッチ数列を作成
 */
void generate_progression() {
    fibonacci.push_back(1);
    fibonacci.push_back(1);
    for (int i = 2; i < MAX; i++) {
        int num = fibonacci[i - 2] + fibonacci[i - 1];
        fibonacci.push_back(num);
        // 素数であればソスナッチ数列に追加
        if (is_prime(num)) {
            sossunachi.push_back(num);
        }
    }
}
/**
 * n番目のフィボナッチ数列とソスナッチ数列を出力
 * 存在しないならNGを出力
 */
void solve(int n) {
    if (fibonacci.size() >= n) {
        cout << fibonacci[n-1];
    } else {
        cout << "NG";
    }
    cout << " ";
    if (sossunachi.size() >= n) {
        cout << sossunachi[n-1];
    } else {
        cout << "NG";
    }
    cout << endl;
}
int main(void) {
    // 2つの数列を作成
    generate_progression();
    int T; cin >> T;
    for (int i = 1; i <= T; i++) {
        int n; cin >> n;
        cout << "Case #" << i << ":" << endl;
        solve(n);
    }
    return 0;
}
