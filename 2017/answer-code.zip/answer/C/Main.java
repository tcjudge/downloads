import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

class Main{
    // フィボナッチ数列，ソスナッチ数列用のリストを定義しておく
    List<Integer> fiboList = new ArrayList<Integer>();
    List<Integer> primeList = new ArrayList<>();

    // 素数判定関数，素数ならtrue，それ以外はfalse
    public boolean checkPrime(int fibo){
        if(fibo < 2) return false; // 2未満は素数ではない
        else if(fibo == 2) return true; // 2は素数である
        else if(fibo % 2 == 0) return false; // 2で割り切れたらそれは素数ではない

        // 1とその数のみでしか割り切れないのが素数であるため，他の数で余りが0になるかを判定する
        // 参考:http://judge.u-aizu.ac.jp/onlinejudge/commentary.jsp?id=ALDS1_1_C
        for(int i = 3; i < Math.sqrt(fibo); i += 2){
            if(fibo % i == 0){
                return false;
            }
        }

        // 素数であるときにのみtrueが返る
        return true;
    }

    // フィボナッチ数列計算関数，再帰的にnまでのフィボナッチ数列を作成する
    public int fibo(int one, int two, int n, int count){
        // 計算した数が素数の場合，その数をソスナッチ数列に加える
        if(checkPrime(one))
            primeList.add(one);

        // フィボナッチ数列へ数を追加する
        fiboList.add(two);

        // nまで求めきった場合，終了する．
        if(count == n)
            return two;

        return fibo(two, one + two, n, ++count);
    }

    public void run() throws IOException{
        // BufferedReaderの定義
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for(int i = 0; i < t; i++){
            fiboList = new ArrayList<>();
            primeList = new ArrayList<>();
            // 値読み取り
            int n = Integer.parseInt(br.readLine());

            // フィボナッチ数列計算関数の呼び出し
            fiboList.add(1);
            fibo(1, 1, 46, 2);

            System.out.printf("Case #%d:\n", i + 1);

            // ソスナッチ数列のサイズが与えられた番目より小さい場合は，ソスナッチ数列にはその番目の数は存在しない
            if(n > primeList.size()){
                System.out.println(fiboList.get(n - 1) + " NG");
            } else{ // ソスナッチ数列に値がある時
                System.out.println(fiboList.get(n - 1) + " " + primeList.get(n - 1));
            }
        }

    }

    public static void main(String... args) throws IOException{
        new Main().run();
    }
}
