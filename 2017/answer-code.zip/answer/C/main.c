/*
 * おまけ
 * unsigned は正の値しか扱わないという宣言
 * 負の値を使わない分使える正の範囲で使えるbit数が増える
 *
 * long long は使うbit数を増やす宣言
 * つまり unsigned long long int は普通に int と宣言するよりも大量のbit数を使える
 */

// 入出力関係
#include<stdio.h>
#include<stdlib.h>
// 数学関連の関数を使うため
#include<math.h>

// フィボナッチの制約
#define FIBO 46
// 先に素数計算して早くするよう
#define PRIME 10000

int main(void) {
    // 出力するべき数列の番号
    int N;
    // フィボナッチ数列
    unsigned long long int fibo[FIBO];
    // カウンタ変数
    unsigned long long int i;
    // ソスナッチ数列
    unsigned long long int sosu[FIBO];
    // 素数
    int prime[PRIME];
    // カウンタ変数
    int count=0;
    // カウンタ変数
    int j;
    // テストケース数
    int T;

    // # 高速化のためだけゾーン #
    // 素数表の初期化
    for(i=0;i<PRIME;i++) {
        prime[i] = 0;
    }
    // 素数の計算
    for(i=0;i<PRIME;i++) {
        for(j=2;j<PRIME;j++) {
            if(i*j >= PRIME) break;
            if(i < 2) {
                prime[i]=1;
                break;
            }
            prime[i*j] = 1;
        }
    }
    // # end #

    // フィボナッチ数列の初期化
    fibo[0] = 1;
    fibo[1] = 1;

    // フィボナッチ数列の計算
    for(i=2;i<FIBO;i++) {
        fibo[i] = fibo[i-2]+fibo[i-1];
        sosu[i] = 0;
    }


    //ソスナッチ数列の初期化
    sosu[0]=0;
    sosu[1]=0;

    // ソスナッチ数列の計算
    for(i=2;i<FIBO;i++) {
        for(j=2;j<=(int)sqrt(fibo[i]);j++) {
            //// 素数の判定
            // 素数かどうかは素数で割れば分かる
            if(j < PRIME) {
                if(prime[j] != 0) ;
                else {
                    if(fibo[i] % j == 0) {
                        break;
                    }
                }
            }
            // 素数表から外れたら
            else if(fibo[i] % j == 0) {
                break;
            }
            ////
        }
        // ソスナッチ数列だったら配列に入れてカウントを進める
        if(j>=(int)sqrt(fibo[i])+1) {
            sosu[count]=fibo[i];
            count++;
        }
        // それ以外は何もしない
        else ;
    }

    // テストケース数を入力
    scanf("%d", &T);

    for(i=1;i<=T;i++) {
        printf("Case #%llu:\n", i);

        // 出力するべき番号の入力
        scanf("%d", &N);
        // フィボナッチ数列の指定された番号の数字を出力
        printf("%llu ", fibo[N-1]);
        // 指定された番号のソスナッチ数列が無い時
        if(sosu[N-1]==0) printf("NG\n");
        // 指定された番号のソスナッチ数列がある時
        else printf("%llu\n", sosu[N-1]);
    }

    return 0;
}

