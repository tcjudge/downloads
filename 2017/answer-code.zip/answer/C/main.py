#!/usr/bin/python
# coding: utf-8
import math

MAX_LENGTH = 46

# フィボナッチ数列の作成
def create_fibonacci():
    fibonacci = [None] * MAX_LENGTH
    fibonacci[0] = 1
    fibonacci[1] = 1
    for i in xrange(2, MAX_LENGTH):
        fibonacci[i] = fibonacci[i-1] + fibonacci[i-2]
    return fibonacci

# 素数の判定
"""
以下高速な素数判定のアルゴリズム
1: 2以下(0, 1)は素数ではない．
2: 2は素数である．
3: 2で割り切れる数（偶数）は素数ではない．
4: 3以上の奇数で割り切れる数は素数ではない．
5: 4: を判定したい数の平方根まで繰り返す．
    ・平方根までで割り切れていない場合，それ以上の数で割り切れることはないため．
"""
def is_prime(num):
    if num < 2:
        return False
    if num == 2:
        return True
    if (num % 2) == 0:
        return False
    for i in xrange(3, int(math.sqrt(num)), 2):
        if (num % i) == 0:
            return False
    return True

# ソスナッチ数列の作成
def create_sosunacci(fibonacci):
    sosunacci = list()
    # フィボナッチ数列の中の素数のみを取り出す
    for element in fibonacci:
        if is_prime(element):
            sosunacci.append(element)
    return sosunacci

def solve(fibonacci, sosunacci):
    length = int(raw_input())
    if length > len(sosunacci):
        print "%d NG" % fibonacci[length-1]
    else:
        print fibonacci[length-1], sosunacci[length-1]

def run():
    # フィボナッチ数列とソスナッチ数列は一度だけ作成する．
    fibonacci = create_fibonacci()
    sosunacci = create_sosunacci(fibonacci)
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve(fibonacci, sosunacci)

if __name__ == "__main__":
    run()
