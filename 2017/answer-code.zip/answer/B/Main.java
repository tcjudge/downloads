import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		int t = Integer.parseInt(scan.nextLine());
		for(int m=1;m<=t;m++){
			System.out.println("Case #"+m+":");
			int a = Integer.parseInt(scan.nextLine());
			int count=0;
			//判定する部分と出力する部分を":"で分ける
			for(int i=0;i<a;i++){
				String str = scan.nextLine();
				String[] split = str.split(":");
				//判定部分が"Friend"なら出力する
				if(split[1].equals("Friend")) {
					System.out.println(split[0]);
					count++;
				}
			}
			//Fiendがいなかった場合の出力
			if(count==0) System.out.println("Not Friends");
		}
	}
}
