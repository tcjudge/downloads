#!/usr/bin/python
# coding: utf-8

def is_friend(attribute):
    return attribute == "Friend"

def solve():
    num_of_person = int(raw_input())
    exist_friend = False # ふれんずが存在するかのフラグ
    for i in xrange(num_of_person):
        name, attribute = raw_input().split(":")
        # ふれんずならば名前を出力し，存在フラグを立てる
        if is_friend(attribute):
            exist_friend = True
            print name
    # フラグが立っていない（ふれんずが存在しない）場合の処理
    if not exist_friend:
        print "Not Friends"

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
