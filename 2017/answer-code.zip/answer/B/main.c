// 入出力関係
#include<stdio.h>
// 文字列処理のためにimport
#include<string.h>

int main(void) {
    // 1テストケースに含まれる人数用
    int n;
    // カウンタ変数
    int i;
    // Frendsがいるかどうかの判定用
    int flag=0;
    // テストケース数
    int T;
    // テストケース用カウンタ変数
    int t;

    // テストケース読み込み
    scanf("%d", &T);

    // テストケース分,テストケース毎の処理を繰り返す
    for(t=1;t<=T;t++) {
        // 文字列前半格納用
        char name[51];
        // 文字列後半格納用
        char type[51];

        // Friendsがいないに初期化
        flag = 0;

        // 入力数を取得する
        scanf("%d", &n);

        // Case数を出力する
        printf("Case #%d:\n", t);

        // n回分,入力がFriendかどうかを判定する
        for(i=0;i<n;i++) {

            // c言語では,文字列の入力後ゴミが残るのでそれを処理する
            scanf("\n");

            // 入力段階で前半文字列と後半文字列を分ける 
            // [^:] ← この記述で ':' 以外を取得する,つまり ':' までの前半文字列を取得
            scanf("%[^:]:%s", name, type);

            // Friendかどうかを判定する
            // Friendの時の処理
            if(strcmp(type, "Friend") == 0) {
                // Friend名を出力
                printf("%s\n", name);
                // Friendが居たのでflagを立てる
                flag = 1;
            }
        }
        // Friendが居なかった時
        if(flag == 0) {
            // 友達がいなかったことを出力
            printf("Not Friends\n");
        }
    }

    return 0;
}

