#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define R 5

int main(void) {
    float Af; // 機体Aの現在の高度(m)
    float Bf; // 機体Bの現在の高度(m)
    float D; // 現在の機体A,B間の距離(m)
    float Va; // 機体Aの速度(m/s)
    float Vb; // 機体Bの速度(m/s)
    float Aa; // 機体Aの向き(度数)
    float Ab; // 機体Bの向き(度数)

    // 機体Aのxy座標
    float Ax;
    float Ay;
    // 機体Bのxy座標
    float Bx;
    float By;
    // 時間の進み
    float t = 0.03f;
    
    // 機体Aの現在のx座標
    float x1;
    // 機体Bの現在のx座標
    float x2;

    // 機体Aのx方向の向き
    float ax_dir = 1;
    // 機体Aのy方向の向き
    float ay_dir = 1;
    // 機体Bのx方向の向き
    float bx_dir = -1;
    // 機体Bのy方向の向き
    float by_dir = 1;
    // 機体AB間の距離
    float kyori = 0;

    // テストケース数
    int T;

    // テストケース数入力
    scanf("%d", &T);

    for(int tt = 1; tt<=T; tt++) {
        // 初期化
        t = 0.03f;
        ax_dir = 1;
        ay_dir = 1;
        bx_dir = -1;
        by_dir = 1;
        kyori = 0;

        // 入力
        scanf("%f %f %f", &Af, &Bf, &D);
        scanf("%f %f", &Va, &Aa);
        scanf("%f %f", &Vb, &Ab);

        // 時間0での衝突判定
        if(Af <= 0.0f || Bf <= 0.0f) {
            printf("Case #%d:\n", tt);
            if(D <= 2*R) printf("AVOID\n");
            else printf("OK\n");
        }
        else {
            //初期化
            Ax = 0;
            Bx = D;
            x1 = Ax;
            x2 = Bx;
            Ay = Af + R;
            By = Bf + R;
            // x軸y軸それぞれのスピードを計算
            float kx_A = t*Va*cos((M_PI*Aa)/180.0f);
            float kx_B = t*Vb*cos((M_PI*Ab)/180.0f);
            float ky_A = t*Va*sin((M_PI*Aa)/180.0f);
            float ky_B = t*Vb*sin((M_PI*Ab)/180.0f);

            // 絶対値化
            kx_A = fabsf(kx_A);
            ky_A = fabsf(ky_A);
            kx_B = fabsf(kx_B);
            ky_B = fabsf(ky_B);
            
            // 移動する向き
            if(Aa < 0) ay_dir = -1;
            if(Ab < 0) by_dir = -1;

            // シミュレート
            while(1) {
                x1 += (ax_dir * kx_A);
                x2 += (bx_dir * kx_B);
                Ay += (ay_dir * ky_A);
                By += (by_dir * ky_B);
                // AB間の距離を計算
                kyori = sqrt( ( (x2-x1)*(x2-x1) + (By-Ay)*(By-Ay) ) );
                // 衝突判定
                if( 2*R >= kyori ) {
                    printf("Case #%d:\n", tt);
                    printf("AVOID\n");
                    break;
                }
                // 着陸判定
                if(Ay-R <= 0.0f || By-R <= 0.0f) {
                    printf("Case #%d:\n", tt);
                    printf("OK\n");
                    break;
                }
                // 通過判定
                if((x2 - x1) <= -2*R) {
                    printf("Case #%d:\n", tt);
                    printf("OK\n");
                    break;
                }
                
            }
        }
    }

    return 0;
}

