#!/usr/bin/python
#coding: utf-8

import math

TIME = 0.03
A = 0
B = 1
RADIUS = 5

# 衝突チェック
def is_collision(distance, velocities):
    d = math.sqrt(math.pow(distance, 2)+math.pow(velocities[A]-velocities[B], 2)) # AとBのユークリッド距離を求める
    return d <= RADIUS*2

# 着陸チェック
def is_landed(altitudes):
    return (altitudes[A] <= RADIUS) or (altitudes[B] <= RADIUS)

def simulate(distance, altitudes, velocities, angles):
    # AB間のx方向の距離がマイナスになるまで続ける．
    while distance >= 0:
        if is_collision(distance, altitudes):
            print "AVOID"
            return
        if is_landed(altitudes):
            break
        # 0.03秒後のそれぞれの高度を求める
        altitudes[A] += velocities[A] * math.sin(math.radians(angles[A])) * TIME
        altitudes[B] += velocities[B] * math.sin(math.radians(angles[B])) * TIME
        # 0.03秒後のAB間のx方向の距離を求める
        distance -= (velocities[A] * math.cos(math.radians(angles[A])) + velocities[B] * math.cos(math.radians(angles[B]))) * TIME
    print "OK"

def solve():
    a_altitude, b_altitude, distance = map(int, raw_input().split())
    a_velocity, a_angle = map(int, raw_input().split())
    b_velocity, b_angle = map(int, raw_input().split())

    simulate(distance, [a_altitude, b_altitude], [a_velocity, b_velocity], [a_angle, b_angle])

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()
if __name__ == "__main__":
    run()
