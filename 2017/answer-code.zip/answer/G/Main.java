import java.io.*;
import java.util.*;

// 飛行機クラス
// 現在の位置（x, f）速度，向きを持つ
class AirPlane{
    double f, v, a, x;
    public AirPlane(double f_, double v_, double a_, double x_){
        this.f = f_;
        this.v = v_ * 0.03;
        this.a = a_;
        this.x = x_;
    }
}

class Main{
    // 着陸している場合:true，していない場合:false
    boolean landed(double f){ return f <= 0.0; }

    // 機体間の距離を得る
    double getDistance(double x1, double y1, double x2, double y2){ return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)); }

    void run() throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // Bufferedreaderを用いて一行ずつ入力を行う
        int T = Integer.parseInt(br.readLine());
        for(int i = 1; i <= T; ++i){
            // f 高度, v 速度, a 角度
            String[] str1 = br.readLine().split(" ");
            Double Af = Double.parseDouble(str1[0]);
            Double Bf = Double.parseDouble(str1[1]);
            Double D = Double.parseDouble(str1[2]);
            String[] str2 = br.readLine().split(" ");
            Double Va = Double.parseDouble(str2[0]);
            Double Aa = Double.parseDouble(str2[1]);
            String[] str3 = br.readLine().split(" ");
            Double Vb = Double.parseDouble(str3[0]);
            Double Ab = Double.parseDouble(str3[1]);

            AirPlane a = new AirPlane(Af, Va, Aa, 0.0);
            AirPlane b = new AirPlane(Bf, Vb, Ab, D);
            boolean isOk = false; // false:AVOID, true:OK
            double previousDistance = getDistance(a.x, a.f, b.x, b.f); // 一つ前の状態の距離を保持
            // 角度分座標が移動する，そこに速度も加わる
            // 横はsin，縦はcosか
            // double time = 0.0;
            while(true){
                if(getDistance(a.x, a.f, b.x, b.f) <= 10.0) { break; }

                if(landed(a.f) || landed(b.f)){
                    isOk = true;
                    break;
                }
                // time += 0.03;

                // 機体の位置の更新
                // Javaには度数をラジアンに変換するメソッドが用意されている
                a.x += a.v * Math.cos(Math.toRadians(a.a));
                a.f += a.v * Math.sin(Math.toRadians(a.a));
                b.x -= b.v * Math.cos(Math.toRadians(b.a));
                b.f += b.v * Math.sin(Math.toRadians(b.a));
                double currentDistance = getDistance(a.x, a.f, b.x, b.f);

                if(currentDistance > previousDistance){
                    isOk = true;
                    break;
                }

            }

            System.out.println("Case #" + i + ":");
            if(isOk)
                System.out.println("OK");
            else
                System.out.println("AVOID");
        }

    }
    public static void main(String... args) throws Exception{
        new Main().run();
    }
}

