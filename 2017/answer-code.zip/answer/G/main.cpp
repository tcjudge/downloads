#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;
using Real = long double;
#define R 5
#define TIME 0.03 // 単位時間

int main(){
    int T; cin >> T;
    for(int nth = 1; nth <= T; ++nth){
        Real a,b,d; cin >> a >> b >> d; 
        Real va, aa; cin >> va >> aa;
        va *= TIME;
        aa = aa * M_PI / 180.0;
        Real vb, ab; cin >> vb >> ab;
        vb *= TIME;
        ab = ab * M_PI / 180.0;
        Real a_x, a_y; // 円の底
        a_x = 0.0; a_y = a;
        Real a_cy; //円の中心座標（xは等しいため不要）
        a_cy = a_y + 5.0;
        Real b_x, b_y;
        b_x = (Real)d; b_y = b;
        Real b_cy = b_y + 5.0;

        bool is_crashed = false;

        // C++のラムダ式
        auto next_x = [](Real x_, Real v, Real radian){return x_ + v * cos(radian);};
        auto next_y = [](Real y_, Real v, Real radian){return y_ + v * sin(radian);};
        auto dist2 = [](Real a_x_, Real a_y_, Real b_x_, Real b_y_){return (a_x_ - b_x_) * (a_x_ - b_x_) + (a_y_ - b_y_) * (a_y_ - b_y_);};
        auto crashed = [](Real a_x_, Real a_y_, Real b_x_, Real b_y_) -> bool{return (a_x_ - b_x_) * (a_x_ - b_x_) + (a_y_ - b_y_) * (a_y_ - b_y_) <= 4 * R * R;};
        auto landed = [](Real y_) -> bool{return y_ <= 0.0;};

        Real pre_d = dist2(a_x, a_cy, b_x, b_cy); // pre_dは，previous disanceの略
        while(true){
            // ぶつかっているかどうか判定
            if(crashed(a_x, a_cy, b_x, b_cy)){
                is_crashed = true;
                break;
            }

            // 飛行機が着陸しているかどうかをチェック
            if(landed(a_y) || landed(b_y)){
                break;
            }

            // 機体の位置の更新
            a_x = next_x(a_x, va, aa);
            a_cy = next_y(a_cy, va, aa);
            a_y = a_cy - R;
            b_x = next_x(b_x, -vb, ab); // 機体Bの進む向きに注意（つまり，vb * -1をすることを忘れないこと）
            b_cy = next_y(b_cy, vb, ab);
            b_y = b_cy - R;

            // 絶対にぶつからない場合，繰り返しから抜け出す判定
            // 一つ前の状態の機体間の距離よりも大きくなるとbreak
            Real c_d = dist2(a_x, a_cy, b_x, b_cy); // c_dは，current_distanceの略
            if(c_d > pre_d){
                break;
            }

            pre_d = c_d;
        }

        cout << "Case #" << nth << ":\n";
        if(is_crashed) cout << "AVOID\n";
        else cout << "OK\n";
    }

    return EXIT_SUCCESS;
}
