#include <iostream>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <cmath>
using namespace std;

int main(){
    int T; cin >> T;

    for(int nth = 1; nth <= T; nth++){
        int c,l; cin >> c >> l;
        vector<int> e(l);
        for(int i = 0; i < l; ++i)
            cin >> e[i];

        // next_permutation関数を使うために，昇順にソートしておく
        // これをしておかなければ，全通りの順列を得られない．
        sort(e.begin(), e.end()); 

        int ans = 0; // 最大の進化数を保持する

        // 順列を求める
        do{
            int sum = 0; // CPを足しわせた結果を保持する変数
            int evolution = 0; // 進化した数
            for(int i = 0; i < e.size(); ++i){
                sum += e[i];

                // コイが進化したら，以下の処理に入る
                if(sum >= c){
                    sum = 0; // 次のコイのために，sum変数を0に初期化
                    evolution++; // 進化した数を++
                }
            }
            ans = max(evolution, ans);
        }while(next_permutation(e.begin(), e.end()));

        cout << "Case #" << nth << ":\n";
        cout << ans << endl;
    }

    return EXIT_SUCCESS;
}
