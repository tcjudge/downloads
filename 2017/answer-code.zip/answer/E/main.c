// 入出力関係
#include<stdio.h>
#include<stdlib.h>

// 制約に対して十分な容量を取っておく
#define N 2000001

// ソート後
int B[N];
// ソート用
int C[N];

// ソート
void countingSort(int A[], int B[], int k, int n){
    int i, j;

    for(i = 0; i <= k; i++){
        C[i] = 0;
    }
    for(j = 1; j <= n; j++){
        C[A[j]]++;
    }   
    for(i = 1; i <= k; i++){
        C[i] = C[i] + C[i - 1];
    } 
    for(j = n; j >= 1; j--){
        B[C[A[j]]] = A[j];
        C[A[j]]--;
    }
}

int main(){
    // 餌に含まれるCP
    int E[N];
    // カウンタ変数
    int i, j, n, k = 0;
    // コイの成長に必要なCP
    int C;
    // 寺子さんの持つ餌の数
    int L;
    // 答え
    int ans;
    // CPの合計値
    int sum;
    // テストケース数
    int T;
    // テストケース用
    int t;

    // テストケース数入力
    scanf("%d", &T);

    for(t=1;t<=T;t++) {
        // 入力
        scanf("%d %d", &C, &L); 

        // 初期化
        k=0;

        // 配列の初期化
        for(i=0;i<N;i++) {
            B[i] = 0;
            E[i] = 0;
        }
        // 餌に含まれるCPを入力
        for(i = 1; i <= L; i++){
            scanf("%d", &E[i]);
            if(k < E[i]) k = E[i];
        }

        // ソート
        countingSort(E, B, k, L);
        
        // 答え初期化
        ans = 0;
        
        // 貪欲法から改造
        for(i=L;i>0;i--) {
            // 餌を使い切ったら
            if(B[i]==0) break;
            // 合計を初期化
            sum = B[i];
            // 取り出した餌の部分を0に
            B[i] = 0;
            // jの初期化
            j=L;
            // 与えた餌の合計が成長に必要なCPを超えるまで
            // ソートしてあるので大きい方から確認する
            while(sum < C) {
                // 餌を使い切ったら
                if(j==0) break;

                // 今まで与えた分と次の分を足すと成長に必要なCPをオーバーするなら
                if(sum+B[j] > C) ;
                // もしピッタリ餌を与えられるなら
                // もしくは,１番小さな餌にたどり着いたら
                else if(sum+B[j]==C || (j==1 && B[j]!=0)){
                    // その餌を与える
                    sum += B[j];
                    // 与えた分の餌を0に
                    B[j] = 0;
                    // 上からもう一度
                    j=L;
                }
                
                // 見るところを進める
                j--;
            }
            // もし与えた餌が成長に必要な分を超えていたら
            if(sum >= C) {
                ans++;
                sum=0;
            }
        }

        // ケース数を出力
        printf("Case #%d:\n", t);
        // 答えを出力
        printf("%d\n", ans);
        scanf("");
    }

    return 0;
}
