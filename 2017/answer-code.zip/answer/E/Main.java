import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;


public class Main {
	static int ans=0;
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		int t = scan.nextInt();
		for(int m=1;m<=t;m++){
			//入力と変数の初期化
			ans=0;
			int cp = scan.nextInt();
			int x = scan.nextInt();
			ArrayList<Integer> e = new ArrayList<Integer>();
			for(int i=0;i<x;i++){
				e.add(scan.nextInt());
			}
			//餌のソート
			Collections.sort(e);
			Collections.reverse(e);
			//一つの餌でCPを満たすものをリストから削除・カウンター変数を増加させる
			Iterator<Integer> it = e.iterator();
			while(it.hasNext()){
				int i =it.next();
				if(i>=cp){
					ans++;
					it.remove();
				}
			}
			//残りの餌の最適な順列を再帰的に探す
			permutingArray(e,1,cp,ans);
			System.out.println("Case #"+m+":");
			System.out.println(ans);
		}
	}
	static void permutingArray(java.util.List<Integer> arrayList, int element,int cp,int count) {
		for (int i = element; i < arrayList.size(); i++) {
			java.util.Collections.swap(arrayList, i, element);
			permutingArray(arrayList, element + 1,cp,count);
			java.util.Collections.swap(arrayList, element, i);
		}
		if (element == arrayList.size() - 1) {
			int sum=0;
			for(int a : arrayList){
				sum+=a;
				if(sum>=cp){
					sum=0;
					count++;
				}
			}
			if(ans<count)ans=count;
		}
	}
}
