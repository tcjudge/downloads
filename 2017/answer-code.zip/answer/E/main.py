#!/usr/bin/python
# coding: utf-8

import itertools

def solve():
    # 入力の読み込み
    need_CP, length = map(int, raw_input().split())
    feeds = map(int, raw_input().split())

    # 数え上げ
    max_grow_up = int() # 育て上げ最大数
    for next_feeds in itertools.permutations(feeds):
        grow_up_count = 0 # ループ内で育てた数
        current_CP = 0 # 現在育てているコイのCP

        # 餌を前から順番に見ていく
        for feed in next_feeds:
            current_CP += feed
            if need_CP <= current_CP:
                grow_up_count += 1
                current_CP = 0
        # これまでの最大と比較
        max_grow_up = grow_up_count if max_grow_up < grow_up_count else max_grow_up
    print max_grow_up

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
