#include <iostream>
using namespace std;
int solve(float N, float F, int P) {
    // 1枚から増やしていく
    for(int i = 1; i <= N; i++) {
        // 1枚も引かない確率の計算
        float over = 1;
        float under = 1;
        for(int j = 0; j < F; j++) {
            over *= N - (i + j);
            under *= N - j;
            // 数が大きくなってくると上辺下辺共に桁を下げる
            // オーバーフロー回避
            while (over > 100000 && under > 10000) {
                over /= 10;
                under /= 10;
            }
        }
        // 1枚でも引く確率に変換
        float rate = 1 - (over / under);
        // 目的の確率を越えれば終了
        if(rate * 100 >= P) {
            return i;
        }
    }
    return -1;
}
int main(void) {
    int T; cin >> T;
    for (int i = 1; i <= T; i++) {
        cout << "Case #" << i << ":" << endl;
        float N, F;
        int P;
        cin >> N >> F >> P;
        cout << solve(N, F, P) << endl;
    }
    return 0;
}
