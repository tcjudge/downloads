import java.io.*;
import java.util.*;

class Main{
    int solve(float N, float F, int P){
        // デッキに入れるカードの枚数を一枚ずつ増やしていく
        for(int i = 1; i <= N; i++){
            float over = 1;
            float under = 1;
            // 1枚も引かない確率を計算する
            for(int j = 0; j < F; j++) {
                over *= N - (i + j);
                under *= N - j;
                // 誤差を計算する
                while (over > 100000 && under > 10000) {
                    over /= 10;
                    under /= 10;
                }
            }
            // 引く確率を計算する
            float rate = 1 - (over / under);
            // もし目的の確率を超えた場合
            if(rate * 100 >= P) {
                return i;
            }
        }
        return -1;
    }

    void run(){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for(int i = 0; i < t; i++){
            float N = sc.nextFloat();
            float F = sc.nextFloat();
            int P = sc.nextInt();

            System.out.printf("Case #%d:\n", i+1);
            System.out.println(solve(N, F, P));
        }
    }

    public static void main(String[] args){
        new Main().run();
    }
}
