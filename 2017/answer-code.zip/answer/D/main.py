#!/usr/bin/python
# coding: utf-8

def solve():
    deck, draw, probability = map(int, raw_input().split())
    # 一枚も引けない確率を求める
    """
    一枚以上引ける確率(p) = 1 - 一枚も引けない確率(q) である．
    引く順番は加味しないので，
    q = (当たりを抜いた枚数 C 引く枚数) / (全枚数 C 引く枚数)　となる．（C はコンビネーションを表す）
    引く枚数を a, 全枚数を n, 当たりの数を x とすると．
    q = ((n - x)! / (a! * (n - x - a)!)) / (n! / (a! * (n - a)!))　となる．
    このとき，1 - q が与えられた確率よりも高くなる x を見つければ良い
    """
    numerator = 1
    denominator = 1
    for i in xrange(deck+1):
        numerator *= (deck-draw-i)
        denominator *= (deck-i)
        # オーバーフローを回避する．
        while (numerator > 1000000000) and (denominator > 1000000000):
            numerator /= 10
            denominator /= 10
        not_draw_possibility = 1.0*numerator/denominator*100
        if 100-not_draw_possibility >= probability:
            print i+1
            break

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
