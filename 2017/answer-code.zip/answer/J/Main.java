import java.util.Scanner;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.*;

public class Main{
    int c[] = new int[16];
    int N;
    int L;

    // timeとcostを同時に保持しておくためのclass
    class Result{
        int time, cost;
        public Result(int time_, int cost_){
            this.time = time_;
            this.cost = cost_;
        }
    }

    public static void main(String[] args) {
        new Main().run();
    }

    // bitの状態から合計スコアを求めて返す
    int calcScore(int bit){
        // 受け取ったint型をビット列の文字列に変換する.
        // 例: 2 -> 10
        String tmpbitString = Integer.toString(bit, 2);

        // Nビットまで0で埋める
        for(int i = tmpbitString.length(); i < N; i++){
            tmpbitString = "0" + tmpbitString;
        }

        // 1が立っている部分のジムのスコアの合計を求める
        String[] bitString = tmpbitString.split("");
        int score = 0;
        for(int i = 0; i < bitString.length ; i++){
            // 1が立っている時
            if(bitString[i].equals("1"))
                score += c[i];
        }
        return score;
    }

    void run(){
        Scanner cin = new Scanner(System.in);
        int T = cin.nextInt();
        for(int m = 0; m < T; m++){
            // N, L, c(ジムのコスト)を受け取る
            N = cin.nextInt();
            L = cin.nextInt();
            for(int i = N - 1; i >= 0; i--){
                c[i] = cin.nextInt();
            }

            // 隣接行列distを定義し，初期化しておく
            int[][] dist = new int[N][N];
            for(int i = 0; i < N; i++){
                for(int j = 0; j < N; j++){
                    dist[i][j] = cin.nextInt();
                }
            }

            // INFをIntの最大値を置く
            int INF = Integer.MAX_VALUE;

            // dpテーブルをNビット状態まで確保し，INFで初期化する
            int[][] dp = new int[1<<N][N];
            for(int i = 0; i < (1<<N); i++){
                for(int j = 0; j < N; j++){
                    dp[i][j] = INF;
                }
            }


            // ジムの場所を0で初期化する
            for(int i = 1, j = 0; i < (1<<N); i<<=1, j++){
                dp[i][j] = 0;
            }

            // メイン処理
            for(int i = 0; i < (1<<N); ++i){
                for(int j = 0; j < N; ++j){

                    // INFの場合は何もしない
                    if(dp[i][j] == INF) continue;
                    for(int k = 0; k < N; ++k){
                        // kビットが立っていたらcontinueする
                        if((i>>k) % 2 == 1) continue;

                        // kビット目を立たせた状態をnextiに代入する
                        int nexti = i | (1<<k);

                        // dpテーブルの更新処理
                        int nextd = dp[i][j] + dist[j][k];
                        dp[nexti][k] = Math.min(dp[nexti][k], nextd);
                    }
                }
            }

            Result res = new Result(INF, 0);
            // 求めたdpテーブルからコストが最大のものを取得する
            for(int i = 0; i < (1<<N); i++){
                for(int j = 0; j < N; j++){
                    if(dp[i][j] <= L){
                        // コストが同じ場合は，時間が短い方を取る
                        if(res.cost == calcScore(i)){
                            if(res.time >= dp[i][j])
                                res = new Result(dp[i][j], calcScore(i));
                        } else if(res.cost <= calcScore(i)) // コストが小さい場合は，大きい方に更新する
                            res = new Result(dp[i][j], calcScore(i));
                    }
                }
            }
            System.out.printf("Case #%d:\n", m+1);
            System.out.println(res.cost + " " + res.time);
        }
    }
}

