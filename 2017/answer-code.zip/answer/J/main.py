#!/usr/bin/python
# coding: utf-8

# cp と 時間を持つクラス
class dp_info:
    cp = int()
    time = int()
    def __init__(self, cp=0, time=0):
        self.cp = cp
        self.time = time

# ひとつ前の状態で最も経過時間の少ないものを返す
def min_time_of_prev(previouses, current_cp):
    max_cp = 0
    min_time = float("inf")
    for info in previouses:
        cp = info["cp"]
        time = info["time"]
        cost = info["cost"]
        if (min_time > time+cost) and (not cp == 0):
            max_cp = current_cp + cp
            min_time = time + cost
    return dp_info(max_cp, min_time)

# bitDPによって最大CPを求める．
def dp(gym, limit, gym_cp, time_table):
    max_state = 2**gym
    dp_table = [[dp_info() for i in xrange(gym)] for j in xrange(max_state)]

    for state in xrange(1, max_state):
        for current_gym in xrange(gym):
            previous_state = state & ((max_state-1) ^ (1 << current_gym))
            if not previous_state:
                dp_table[state][current_gym] = dp_info(gym_cp[current_gym], 0)
                continue
            if previous_state == state:
                continue
            dp_table[state][current_gym] = min_time_of_prev(
                # dict の list を内包表記で作成している．
                [
                    {
                        "cp": dp_table[previous_state][previous_gym].cp,
                        "time": dp_table[previous_state][previous_gym].time,
                        "cost": time_table[previous_gym][current_gym]
                    } for previous_gym in xrange(gym) if ((1 << previous_gym) & previous_state)
                ],
                gym_cp[current_gym]
            )
    return sorted([(element.cp, element.time) for row in dp_table for element in row if element.time <= limit], key=lambda x:(-x[0],x[1]))[0]

def solve():
    gym, limit = map(int, raw_input().split())
    gym_cp = map(int, raw_input().split())
    time_table = []
    for _ in xrange(gym):
        time_table.append(map(int, raw_input().split()))
    ans = dp(gym, limit, gym_cp, time_table)
    print "%d %d" % (ans[0], ans[1])

def run():
    t = int(raw_input())
    for i in xrange(1, t+1):
        print "Case #%d:" % i
        solve()

if __name__ == "__main__":
    run()
