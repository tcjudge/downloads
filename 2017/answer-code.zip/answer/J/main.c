#include <stdlib.h> //EXIT_SUCCESS用
#include <stdio.h> // 入出力
#include <limits.h> // INT_MAX用
typedef long long int ll;
#define INF INT_MAX // dpテーブル初期化定数

int main(){
    int T;
    int nth;
    scanf("%d", &T);

    for(nth = 1; nth <= T; ++nth){
        int n,l;
        scanf("%d %d", &n, &l);

        // CPの入力
        int cp[15];
        int i;
        for(i = 0; i < n; ++i)
            scanf("%d", &cp[i]);

        // 時間の入力
        int time_[15][15], j;
        for(i = 0; i < n; ++i){
            for(j = 0; j < n; ++j){
                scanf("%d", &time_[i][j]);
            }
        }

        // 各状態のビットが立っている（つまり訪れた）ジムのCPの合計値を求める
        int sums[1 << 15];
        int bitset;
        for(bitset = 1; bitset < (1 << n); ++bitset){
            int sum = 0;
            for(j = 0; j < n; ++j){
                if((bitset>>j) % 2 == 1){
                    sum += cp[j];   
                }
            }
            sums[bitset] = sum;
        }

        // dpテーブル
        ll dp[1 << 15][15];

        for(bitset = 1; bitset < (1 << 15); ++bitset){
            for(j = 0; j < 15; ++j){
                dp[bitset][j] = INF;
            }
        }

        int ans_cp = 0; // 答えのCPを保持する変数
        int ans_time = -1; // 答えの時間を保持する変数
        int gym;
        // init dp table
        for(bitset = 1, gym = 0; bitset < (1 << n); bitset<<=1, gym++){
            dp[bitset][gym] = 0;
            if(ans_cp < cp[gym]) ans_cp = cp[gym];
        }

        int current_gym, next_gym;
        for(bitset = 1; bitset < (1 << n); ++bitset){
            for(current_gym = 0; current_gym < n; ++current_gym){
                if(dp[bitset][current_gym] == INF) continue; // bitsetの中にcurrent_gymのビットは立っていない
                // 配るDP（つまり，現在の状態から次の状態への遷移）
                for(next_gym = 0; next_gym < n; ++next_gym){
                    if((bitset>>next_gym) % 2 == 1) continue; // 既に訪れたジム

                    int next_bitset = bitset | (1 << next_gym);
                    ll next_time = dp[bitset][current_gym] + time_[current_gym][next_gym];

                    if(dp[next_bitset][next_gym] > next_time)
                        dp[next_bitset][next_gym] = next_time;
                    // 答えの更新
                    // dpテーブルが更新された場合，次のbitsetになるまでに要した時間が制限時間内である場合
                    // 1. 次の状態の合計CPが，現在のものよりも大きければ，CPと時間を更新
                    // 2. 次の状態の合計CPが，現在のものと等しく，ans_timeが持つ時間よりも小さければ，CPと時間を更新
                    if(next_time <= l){
                        if(ans_cp < sums[next_bitset]){
                            ans_cp = sums[next_bitset];
                            ans_time = next_time;
                        }else if(ans_cp == sums[next_bitset] && next_time < ans_time){
                            ans_time = next_time;
                        }
                    }
                }
            }
        }

        // 答えの出力
        printf("Case #%d:\n", nth);
        printf("%d %d\n", ans_cp, ans_time);
    }
    return EXIT_SUCCESS;
}
