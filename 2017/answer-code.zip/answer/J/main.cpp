#include <iostream>
#include <vector>
#include <cstdlib>
#include <climits>
#include <unordered_map>
#include <utility>
using namespace std;
using ll = long long;
using P = pair<int, ll>;
template<typename type>
using Matrix = vector<vector<type>>; // エイリアステンプレート(C++11)によって任意の型を取る２次元配列を定義
#define INF INT_MAX // dpテーブル用初期化定数

int main(){
    int T; cin >> T;

    for(int nth = 1; nth <= T; ++nth){
        int n,l; cin >> n >> l;

        // CPの入力
        vector<int> cp(n);
        for(int i = 0; i < n; ++i)
            cin >> cp[i];

        // 時間の入力
        Matrix<int> time(n, vector<int>(n));
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < n; ++j){
                cin >> time[i][j];
            }
        }

        // 各状態のビットが立っている（つまり訪れた）ジムのCPの合計値を求める
        unordered_map<int, int> sums;
        for(int bitset = 1; bitset < (1 << n); ++bitset){
            int sum = 0;
            for(int j = 0; j < n; ++j){
                if((bitset>>j) % 2 == 1){
                    sum += cp[j];   
                }
            }
            sums.insert(make_pair(bitset, sum));
        }

        // dpテーブル
        Matrix<ll> dp(1 << n, vector<ll>(n, INF));

        // pair型のans変数は限られた時間内で得られる最大のCPと
        // そのCPを得るのにかかる最小時間が格納される
        P ans = make_pair(-1, 0); // first:cp, second:time
        // init dp table
        for(int bitset = 1, gym = 0; bitset < (1 << n); bitset<<=1, gym++){
            dp[bitset][gym] = 0;
            if(ans.first < cp[gym]) ans.first = cp[gym];
        }

        for(int bitset = 1; bitset < (1 << n); ++bitset){
            for(int current_gym = 0; current_gym < n; ++current_gym){
                if(dp[bitset][current_gym] == INF) continue; // bitsetの中にcurrent_gymのビットは立っていない
                // 配るDP（つまり，現在の状態から次の状態への遷移）
                for(int next_gym = 0; next_gym < n; ++next_gym){
                    if((bitset>>next_gym) % 2 == 1) continue; // 既に訪れたジム

                    int next_bitset = bitset | (1 << next_gym);
                    ll next_time = dp[bitset][current_gym] + time[current_gym][next_gym];

                    dp[next_bitset][next_gym] = min(next_time, dp[next_bitset][next_gym]);

                    // 答えの更新
                    // dpテーブルが更新された場合，次のbitsetになるまでに要した時間が制限時間内である場合
                    // 1. 次の状態の合計CPが，現在のものよりも大きければ，CPと時間を更新
                    // 2. 次の状態の合計CPが，現在のものと等しく，ans変数が持つ時間よりも小さければ，CPと時間を更新
                    if(next_time <= l){
                        if(ans.first < sums.at(next_bitset)){
                            ans = make_pair(sums.at(next_bitset), next_time);
                        }else if(ans.first == sums.at(next_bitset) && next_time < ans.second){
                            ans = make_pair(sums.at(next_bitset), next_time);
                        }
                    }
                }
            }
        }

        cout << "Case #" << nth << ":\n";
        cout << ans.first << ' ' << ans.second << '\n';
    }
    return EXIT_SUCCESS;
}
