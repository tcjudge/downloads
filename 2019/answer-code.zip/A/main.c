#include<stdio.h>
#include<string.h>

int main(void) {
	int T;
	scanf("%d", &T);
	for (int i = 1; i <= T; i++) {
		printf("Case #%d:\n", i);

		int L, R;
		scanf("%d %d", &L, &R);

		if (L < R) {
			printf("RIGHT\n");
		} else if (L > R) {
			printf("LEFT\n");
		} else {
			printf("EQUAL\n");
		}
	}
}