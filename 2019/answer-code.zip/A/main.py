#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
	L, R = map(int, raw_input().split())

	if L < R:
		return "RIGHT"
	elif L > R:
		return "LEFT"
	else:
		return "EQUAL"

if __name__ == "__main__":
    T = int(input())
    for i in range(T):
        print "Case #" + str(i+1) + ":"
        print solve()
