import java.util.Scanner;

public class Main{
  private Scanner scanner;

  public Main(){
    this.scanner = new Scanner(System.in);
  }

  private void compare(){
    int l = this.scanner.nextInt();
    int r = this.scanner.nextInt();
    if(l < r){
      System.out.println("RIGHT");
    }else if(l > r){
      System.out.println("LEFT");
    }else{
          System.out.println("EQUAL");
    }
  }

  public void run(){
    int testcase = this.scanner.nextInt();
    for(int i = 1; i <= testcase; i++){
      System.out.println("Case #" + i + ":");
      this.compare();
    }
  }

  public static void main(String[] args){
    Main judge = new Main();
    judge.run();
  }
}
