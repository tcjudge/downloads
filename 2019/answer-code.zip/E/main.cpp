#include<iostream>
#include<vector>
using namespace std;

void solve() {
	int N;
	cin >> N;
	int num = (N - 1) % 9 + 1;
	int count = (N - 1) / 9 + 2;
	for (int i = 0; i < count; ++i) {
		cout << num;
	}
	cout << endl;
}

int main(void) {
	int t;
	cin >> t;
	for (int i = 1; i <= t; ++i) {
		cout << "Case #" << i << ":" << endl;
		solve();
	}
	return 0;
}
