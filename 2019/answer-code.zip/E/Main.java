import java.util.Scanner;

public class Main {

	public static int getRepdigit(int index, int[] repdigits) {
		if (repdigits[index] != 0)
			return repdigits[index];

		if (repdigits[index - 1] == 0)
			repdigits[index - 1] = getRepdigit(index - 1, repdigits);

		int val = repdigits[index - 1];
		int count = 0;
		while (val >= 10) {
			val /= 10;
			count++;
		}

		int repNum = val + 1;

		if (val == 9) {
			repNum = 1;
			count++;
		}

		for (int i = 0; i <= count; i++)
			repdigits[index] += repNum * Math.pow(10, i);

		return repdigits[index];

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int tc = sc.nextInt();
		int[] repdigits = new int[60];
		repdigits[0] = 11;

		for (int i = 0; i < tc; i++) {
			int index = sc.nextInt();

			System.out.println("Case #" + (i + 1) + ":");
			System.out.println(getRepdigit(index - 1, repdigits));
		}
	}
}
