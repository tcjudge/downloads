#include <stdio.h>

void run() {
	int n;
	scanf("%d", &n);
	int digit = (n - 1) % 9 + 1;
	int count = (n - 1) % 9 + 2;
	for (int i = 0; i < count; ++i) {
		printf("%d", digit);
	}
	printf("\n");
}

int main() {
	int t;
	scanf("%d", &t);
	for(int i = 1; i <= t; i++) {
		printf("Case #%d:\n", i);
		run();
	}
	return 0;
}