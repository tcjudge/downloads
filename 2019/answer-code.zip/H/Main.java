import java.util.Scanner;

public class Main {
	static int sort(int val,boolean descend){
		char[] digits = String.format("%04d", val).toCharArray();
		char[] sortedDigits = new char[4];
		for(int i = 0 ; i < sortedDigits.length ; i++) {
			int insertN = i;
			char n = digits[i];
			
			for(int j = i-1 ; j >= 0 ; j--) {

			boolean swap = descend ? sortedDigits[j] < n : sortedDigits[j] > n;

				if(swap) {
					sortedDigits[j+1] = sortedDigits[j];
					insertN = j;
				}else {
					insertN = j+1;
					break;
				}
			}
			sortedDigits[insertN] = n;
		}

		return Integer.parseInt(new String(sortedDigits));
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int tc = sc.nextInt();

		for(int i = 0 ; i < tc ; i++) {
			System.out.println("Case #" + (i+1) + ":");
			int val = sc.nextInt();
			int count = 0;

			while((val != 6174 && val != 0)) {
				count++;
				int max = sort(val,true);
				int min = sort(val,false);

				val = max - min;
			}

			System.out.println(count);
		}
	}
}
