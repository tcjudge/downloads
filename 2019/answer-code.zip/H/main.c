#include <stdio.h>
#include <stdlib.h>

#define CAPRECA 6174

int asc (const void *a, const void *b) {
	return *(int*)a - *(int*)b;
}

int desc (const void *a, const void *b) {
	return *(int*)b - *(int*)a;
}

int sort(int n, int flag) {
	int d[4];
	for (int i = 0; i < 4; ++i) {
		d[i] = n % 10;
		n /= 10;
	}
	if(flag) qsort(d, 4, sizeof(int), asc);
	else qsort(d, 4, sizeof(int), desc);

	return d[3] * 1000 + d[2] * 100 + d[1] * 10 + d[0];
}

void run() {
	int n;
	scanf("%d", &n);
	int count = 0;

	while(n != CAPRECA && n != 0) {
		count++;
		int max = sort(n, 1);
		int min = sort(n, 0);
		n = max - min;
	}

	printf("%d\n", count);
}

int main() {
	int t;
	scanf("%d", &t);
	for (int i = 1; i <= t; i++) {
		printf("Case #%d:\n", i);
		run();
	}
	return 0;
}