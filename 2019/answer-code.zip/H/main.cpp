#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <sstream>

using namespace std;

const int capreca = 6174;

int sort(int n, bool flag = false) {
	ostringstream ss;
	ss << setw(4) << setfill('0') << n;
	string input = ss.str();

	vector<char> data(input.begin(), input.end());

	sort(data.begin(), data.end());
	if(flag) reverse(data.begin(), data.end());

	string result(data.begin(), data.end());
	return stoi(result);
}

void run() {
	int n;
	cin >> n;
	int count = 0;

	while(n != capreca && n != 0) {
		count++;

		int max = sort(n, true);
		int min = sort(n);

		n = max - min;
	}

	cout << count << endl;
}

int main() {

	run();

	return 0;
}