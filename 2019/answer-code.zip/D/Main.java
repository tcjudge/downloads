import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int tc = sc.nextInt();

		for (int i = 0; i < tc; i++) {
			String text = sc.next();

			int time = 0;

			for (int j = 0; j < text.length(); j++) {
				char c = text.charAt(j);

				if (c >= 'a')
					time += c - 'a' + 1;
				else
					time += c - 'A' + 1 + 26;
			}

			System.out.println(time);

			System.out.println("Case #" + (i + 1) + ":");
		}
	}
}
