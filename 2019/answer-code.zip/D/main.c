#include<stdio.h>
#include<string.h>

int main(void) {
	int T;
	scanf("%d", &T);
	for (int i = 1; i <= T; i++) {
		printf("Case #%d:\n", i);

		char S[45];
		scanf("%s", S);

		int answer = 0;
		int j;
		for (j = 0; j < strlen(S); j++) {
			if(S[j] <= 90) {
				answer += S[j] - 38;
			} else {
				answer += S[j] - 96;
			}
		}

		printf("%d\n", answer);
	}
	return 0;
}