#include <iostream>

using std::cout;
using std::cin;
using std::endl;

struct set{
    int price;
    int size;
};

int tc;
int n,budget;

int* budgets;
int* sizes;

set calc(int num,int budget);

int main(int argc, const char * argv[]) {

    cin >> tc;

    for(int j = 0 ; j < tc ; j++){
        cin >> n;
        cin >> budget;

        budgets = new int[n+1];
        sizes = new int[n+1];


        for(int i = 1 ; i <= n ; i++){
            cin >> budgets[i];
            cin >> sizes[i];
        }

        set s = calc(n,budget);
        cout << "Case#" << j+1 << ":" << endl;
        cout << s.price << "," << s.size << endl;
    }

    return 0;
}

set calc(int num,int budget){
    if(num == 0)
        return {::budget - budget,0};
    else if(budget < budgets[num])
        return calc(num-1,budget);
    else {
        set s1 = calc(num-1,budget);
        set s2 = calc(num-1,budget - budgets[num]);
        s2.size += sizes[num];

        if(s1.size == s2.size)
            if(s1.price > s2.price)
                return s1;
            else
                return s2;
        else if(s1.size > s2.size)
            return s1;
        else
            return s2;
    }
}
