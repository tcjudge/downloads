import java.util.Scanner;

public class Main {
	int n,budget;
	int[] budgets;
	int[] sizes;

	Scanner sc;
	int tc;

	Main(){
		sc = new Scanner(System.in);
	}


	void calcAndPrint() {
		tc = sc.nextInt();

		for(int j = 0 ; j < tc ; j++) {
			n = sc.nextInt();
			budget = sc.nextInt();

			budgets = new int[n+1];
			sizes = new int[n+1];

			for (int i = 1; i <= n; i++) {
				int price = sc.nextInt();
				int size = sc.nextInt();
				budgets[i] = price;
				sizes[i] = size;
			}

			Set result = getResult();
			System.out.println("Case #" + (j+1) + ":");
			System.out.println(result.price + " " + result.size);
		}
	}

	Set getResult(){
		return calc(n,budget);
	}

	Set calc(int num, int budget) {
		if (num == 0) {
			return new Set(this.budget - budget,0);
		} else if (budget < budgets[num]) {
			return calc(num - 1, budget);
		} else {
			Set set1 = calc(num-1, budget);
			Set set2 = calc(num - 1, budget - budgets[num]);
			set2.size += sizes[num];

			if(set1.size == set2.size) {
				return set1.price > set2.price ? set1 : set2;
			}else {
				return set1.size > set2.size ? set1 : set2;
			}
		}
	}

	public static void main(String[] args) {

		new Main().calcAndPrint();
	}

	class Set{
		public Set(int price,int size) {
			this.price = price;
			this.size = size;
		}
		int price;
		int size;
	}
}
