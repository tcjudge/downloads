import java.util.Scanner;

public class main{
    //素数判定
    private static Integer isPrime(Integer N){
        if(N==2){ return 1;}
        else if(N%2==0){ return 0;}
        else{
            Double sqrtN = Math.sqrt(N);
            for(int i=3; i<=sqrtN; i++){
                if(N%i==0){ return 0;}
            }
            return 1;
        }
    }
    
    //単一テストケース
    private static void run(){
        Scanner scan = new Scanner(System.in);
        Integer N = scan.nextInt();
        Integer prime_cnt = 1;
        for(int i=3; i<=N; i+=2){
            if(isPrime(i)==1){
                prime_cnt++;
                if(isPrime(prime_cnt)==1){
                    System.out.println(i);
                }
            }
        }
    }
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        Integer testcase = scan.nextInt();
        for(int i=1; i<=testcase; i++){
            System.out.println("Case #"+i+":");
            run();
        }
    }
    

}
