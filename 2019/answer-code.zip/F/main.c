#include<stdio.h>
#include<stdlib.h>
#include <math.h>

#define MIN 3

int check_prime(int num)
{
    if (num == 2) return 1;
    else if(num % 2 == 0) return 0; // 偶数はあらかじめ除く

    double sqrtNum = sqrt(num);
    for (int i = 3; i <= sqrtNum; i += 2)
    {
        if (num % i == 0)
        {
            return 0;
        }
    }
    return 1;
}

void run()
{
    int n;
    scanf("%d",&n);
    
    int prime_cnt=1;
    for(int i=MIN; i<=n; i+=2){
        if(check_prime(i)==1){
            prime_cnt++;
            if(check_prime(prime_cnt)==1){
                printf("%d\n",i);
            }
        }
    }
    return;
}

int main()
{
    int testcase;
    scanf("%d",&testcase);
    
    for(int t=1; t<=testcase; t++){
        printf("Case #%d:\n",t);
        run();
    }
    
    return EXIT_SUCCESS;
}
