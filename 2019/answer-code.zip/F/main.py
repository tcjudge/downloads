# coding: utf-8

def is_prime(n):
    if(n==2):
        return 1
    elif (n%2)==0:
        return 0
    else:
        for i in range(3,n,2):
            if (n%i)==0:
                return 0
        return 1

def run():
    n = int(input())
    prime_cnt = 1  # conut
    for i in range(3,n+1):
        if is_prime(i) == 1:
            prime_cnt += 1
            if is_prime(prime_cnt) == 1:
                print(i)
        

def main():
    testcase = int(input())
    for t in range(testcase):
        print("Case #"+str(t+1)+":")
        run()

if __name__ == "__main__":
    main()
