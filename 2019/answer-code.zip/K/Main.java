import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int tc = sc.nextInt();

		for (int t = 0; t < tc; t++) {
			int wordNum = sc.nextInt();

			HashSet<Integer> nodes = new HashSet<>();

			boolean[][] edges = new boolean[26][26];
			for (int i = 0; i < 26; i++) {
				for (int j = 0; j < 26; j++) {
					edges[i][j] = false;
				}
			}

			int[] topFreqs = new int[26];
			int[] tailFreqs = new int[26];
			Arrays.fill(topFreqs, 0);
			Arrays.fill(tailFreqs, 0);

			for (int i = 0; i < wordNum; i++) {
				String word = sc.next();
				int top = word.charAt(0) - 'a';
				int tail = word.charAt(word.length() - 1) - 'a';

				edges[top][tail] = true;

				topFreqs[top]++;
				tailFreqs[tail]++;

				nodes.add(top);
				nodes.add(tail);
			}

			boolean result = true;

			for (int node : nodes) {
				if (topFreqs[node] != tailFreqs[node]) {
					result = false;
					break;
				}
			}

			if (result) {
				boolean[] reached = new boolean[26];
				Arrays.fill(reached, false);

				List<Integer> tailNodes = new ArrayList<>();

				tailNodes.add(nodes.toArray(new Integer[0])[0]);

				while (!tailNodes.isEmpty()) {
					int top = tailNodes.remove(0);

					for (int tail : nodes) {
						if (!reached[tail] && edges[top][tail]) {
							reached[tail] = true;
							tailNodes.add(tail);
						}
					}
				}

				for (int node : nodes) {
					if (!reached[node]) {
						result = false;
						break;
					}
				}
			}

			System.out.println("Case #" + (t + 1) + ":");
			System.out.println(result ? "OK" : "NG");
		}
	}
}
