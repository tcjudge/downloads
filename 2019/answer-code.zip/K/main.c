#include <stdio.h>
#include <string.h>

#define MAX 26

int parent[MAX], rank[MAX];
int start[MAX], end[MAX];
int used[MAX];

void init() {
	for(int i = 0; i < MAX; i++) {
		parent[i] = i;
		rank[i] = 0;
		start[i] = 0;
		end[i] = 0;
		used[i] = 0;
	}
}

int root(int x) {
	if(parent[x] == x) {
		return x;
	} else {
		return parent[x] = root(parent[x]);
	}
}

int same(int x, int y) {
	return root(x) == root(y);
}

void unite(int x, int y) {
	x = root(x);
	y = root(y);
	if(x == y) {
		return;
	}

	if(rank[x] < rank[y]) {
		parent[x] = y;
	} else {
		parent[y] = x;
		if(rank[x] == rank[y]) {
			rank[x]++;
		}
	}
}

void run() {
	int n;
	scanf("%d", &n);

	init();
	for(int i = 0; i < n; i++) {
		char s[MAX];
		scanf("%s", s);
		int head = s[0] - 'a';
		int tail = s[strlen(s) - 1] - 'a';
		start[head]++;
		end[tail]++;
		unite(head, tail);
		used[head] = 1;
		used[tail] = 1;
	}

	int flag = 1;

	for(int i = 0; i < MAX; i++) {
		if(start[i] != end[i]) {
			flag = 0;
			break;
		}
	}

	if(flag) {
		for(int i = 0; i < MAX; i++) {
			for(int j = 0; j < MAX; j++) {
				if(used[i] && used[j]) {
					if(!same(i, j)) {
						flag = 0;
						break;
					}
				}
			}
		}
	}

	if(flag) {
		printf("OK\n");
	} else {
		printf("NG\n");
	}
}

int main() {
	int t;
	scanf("%d", &t);
	for (int i = 1; i <= t; i++) {
		printf("Case #%d:\n", i);
		run();
	}
	return 0;
}