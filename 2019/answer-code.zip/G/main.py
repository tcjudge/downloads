#!/usr/bin/python
# -*- coding: utf-8 -*-

import heapq

def solve():
    C, R = map(int, raw_input().split())
    c = [raw_input().split() for _ in range(R)]

    for y in range(R):
        for x in range(C):
            if c[y][x] == "1":
                sy = y + 1
                sx = x + 1
                c[y][x] = "0"
            elif c[y][x] == "2":
                gy = y + 1
                gx = x + 1
                c[y][x] = "0"

    q = []
    visited = set()
    heapq.heappush(q, (0, sx, sy))
    while len(q) > 0:
        v, x, y = heapq.heappop(q)
        if (x, y) in visited:
            continue
        if x == -1 or y == -1 or x == C+1 or y == R+1:
            continue
        visited.add((x, y))
        if x == gx and y == gy:
            return v
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            nx, ny = x + dx, y + dy
            if (nx, ny) in visited:
                continue
            try:
                if c[ny-1][nx-1] == "0":
                    heapq.heappush(q, (v+1, nx, ny))
            except:
                pass
    return 0

def main():
    testcase = int(input())
    for t in range(testcase):
        print "Case #"+str(t+1)+":"
        print solve()

if __name__ == "__main__":
    main()
