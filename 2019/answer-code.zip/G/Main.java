import java.util.Scanner;

public class Main {
	public static void search(int dist, int[][] map, int[][] searchMap, int fromVX, int fromVY, int x, int y) {
		if (map[y][x] == 3 || (searchMap[y][x] > 0 && searchMap[y][x] <= dist))
			return;

		searchMap[y][x] = dist;

		if (map[y][x] == 2) {
			searchMap[y][x] = dist;
			return;
		}

		for (int nextVX = -1; nextVX <= 1; nextVX++) {
			int nextX = x + nextVX;

			if (nextVX * -fromVX > 0 || nextX < 0 || nextX >= searchMap[0].length)
				continue;

			for (int nextVY = -1; nextVY <= 1; nextVY++) {
				if (nextVX * nextVY != 0 || nextVX + nextVY == 0) {
					continue;
				}

				int nextY = y + nextVY;

				if (nextVY * -fromVY > 0 || nextY < 0 || nextY >= searchMap.length)
					continue;

				search(dist + 1, map, searchMap, nextVX, nextVY, nextX, nextY);
			}
		}

		return;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int tc = sc.nextInt();

		for(int i = 0 ; i < tc ; i++) {
			int w = sc.nextInt();
			int h = sc.nextInt();

			int[][] map = new int[h][w];
			int[][] searchMap = new int[h][w];

			int stX = 0, stY = 0;
			int gX = 0, gY = 0;
			for (int y = 0; y < h; y++) {
				for (int x = 0; x < w; x++) {
					map[y][x] = sc.nextInt();

					searchMap[y][x] = 0;
					switch (map[y][x]) {
					case 1:
						stX = x;
						stY = y;
						break;
					case 2:
						gX = x;
						gY = y;
						break;
					case 3:
						searchMap[y][x] = -1;
						break;
					default:
						break;
					}
				}
			}

			search(1, map, searchMap, 0, 0, stX, stY);

			int dist = searchMap[gY][gX] > 0 ? searchMap[gY][gX]-1 : 0;

			System.out.println("Case #" + (i+1) + ":");
			System.out.println(dist);
		}

	}
}
