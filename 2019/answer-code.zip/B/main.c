#include<stdio.h>
#include<stdlib.h>

int main(){
  int t;
  scanf("%d\n", &t);
  for(int i = 1; i <= t; i++){
    printf("Case #%d:\n", i);

    int n;
    scanf("%d\n", &n);

    int result = 0;
    for(int j = 0; j < n; j++){
      int price;
      scanf("%d\n", &price);
      result += price;
    }
    result += 200;
    printf("%d\n", result);
  }
  return 0;
}
