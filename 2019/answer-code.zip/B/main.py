#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
	N = int(input())
	result = 0
	for i in range(N):
		result += int(input())

	result += 200

	return result

if __name__ == "__main__":
    T = int(input())
    for i in range(T):
        print "Case #" + str(i+1) + ":"
        print solve()
