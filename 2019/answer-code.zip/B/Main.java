import java.util.Scanner;

public class Main{
  private Scanner scanner;

  public Main(){
    this.scanner = new Scanner(System.in);
  }

  private void calc(){
    int n = this.scanner.nextInt();
    int result = 0;
    for(int i = 1; i <= n; i++){
      result += this.scanner.nextInt();
    }
    result += 200;
    System.out.println(result);
  }

  public void run(){
    int testcase = this.scanner.nextInt();
    for(int i = 1; i <= testcase; i++){
      System.out.println("Case #" + i + ":");
      this.calc();
    }
  }

  public static void main(String[] args){
    Main judge = new Main();
    judge.run();
  }
}
