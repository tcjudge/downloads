#include<stdio.h>
#include<stdlib.h>

int main()
{
    int t;
    scanf("%d",&t);
    int n,p,a;
    for(int test=1; test<=t; test++){
        scanf("%d %d",&n,&p);
        printf("Case #%d:\n",test);
        for(int i=1; i<=n; i++){
            scanf("%d",&a);
            printf("%d\n",(p%(a+1)));
        }
    }
    return EXIT_SUCCESS;
}
