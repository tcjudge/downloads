# coding:utf-8

def main():
    testcase = int(input())
    for t in range(testcase):
        print("Case #"+str(t+1)+":")
        np = input().split()
        n = int(np[0])
        p = int(np[1])
        for i in range(n):
            a = int(input())
            print(p%(a+1))
        
if __name__ == "__main__":
    main()
