import java.util.Scanner;


public class main{
    public static void Count(){
        Scanner scan = new Scanner(System.in);
        Integer n = scan.nextInt();
        Integer p = scan.nextInt();
        for(Integer i=0; i<n; i++){
            Integer a = scan.nextInt();
            System.out.println(p%(a+1));
        }
    }
    
    public static void run(){
        Scanner scan = new Scanner(System.in);
        Integer testcase = scan.nextInt();
            for(Integer i=1; i<=testcase; i++){
                System.out.println("Case #"+i+":");
                Count();
            }
    }
    public static void main(String[] args){
        run();
    }
}
