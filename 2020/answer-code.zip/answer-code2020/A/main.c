#include <stdio.h>
#include <stdlib.h>


void solve(){
	int A, B;
	scanf("%d %d", &A, &B);
	if(A>=B) { printf("%d\n", A-B); }
	else { printf("-1\n"); }
}

int main(){
	int T;
	scanf("%d", &T);

	int i;
	for(i=1; i<=T; i++){
		printf("Case #%d:\n",i);
		solve();
	}
	
	return EXIT_SUCCESS;
}