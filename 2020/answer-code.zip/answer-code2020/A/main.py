#!usr/local/bin/python3

def solve():
	A,B = map(int, input().split(' '))
	if A>=B:
		print(A-B)
	else:
		print(-1)

t = int(input())
for i in range(t):
	print('Case #{}:'.format(i+1))
	solve()