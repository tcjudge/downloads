#include <iostream>
#include <vector> 
using namespace std;
int a_fun();

int main(){
    int a;
    std::cin >> a;
    for (int i =0; i < a; i++){
        cout<< "Case #"<< i+1 << ":"<<endl;
        a_fun();
    }
}

int a_fun(void)
{
    std::string a;
    std::string b;
    std::cin >> a;
    std::cin >> b;  
    vector<vector<int>> dp(5001, vector<int>(5001));
    for (int i=0; i < b.length()+1;i++){
        dp.at(0).at(i)=i;
    }
    for (int i=0; i < a.length()+1;i++){
        dp.at(i).at(0)=i;
    }
    for (int i=1; i < a.length()+1;i++){
        for (int j=1; j < b.length()+1;j++){
            dp.at(i).at(j)=std::min(dp.at(i-1).at(j)+1,std::min(dp.at(i).at(j-1)+1,(dp.at(i-1).at(j-1)+(a.at(i-1)==b.at(j-1)?0 : 1 ))));
        }
    }
    std::cout << dp[a.length()][b.length()] <<std::endl;
}