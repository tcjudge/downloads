#!usr/bin/python

def solve():
	N = int(input())
	profile = {}
	for i in range(N):
		X, Y = raw_input().split()
		profile[X] = int(Y)

	profile = sorted(profile.items(), key=lambda x: (x[1], x[0]))

	result = ''
	for i in range(N):
		if i == N-1:
			result = result + profile[i][0]
		else:
			result = result + profile[i][0] + '\n'

	return result

T = int(input())
for i in range(T):
	print('Case #{}:'.format(i+1))
	print(solve())