#incldue<iostream>

using namespace std;


void solve(){
	int N;
    cin >> N;
    string name;
    int height;
    map<string, int> mp;
    for(int i=0; i<N; i++){
        cin >> name >> height;
        mp.insert(std::make_pair(name, height));
    }
    vector<pair<int, string>> v;
    for (map<string, int>::iterator it = mp.begin(); it != mp.end(); it++) {
        v.push_back({ it->second, it->first });
    }
    sort(v.begin(), v.end());

    for (auto V : v) {
        cout << V.second << endl;
    }
}

int main(){
	int T;
	cin >> T;
	for(int i=1; i<=T; i++){
		cout << "Case #"<<i<<":"<<endl;
		solve();
	}
}