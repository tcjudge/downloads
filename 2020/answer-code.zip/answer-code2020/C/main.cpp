  
#include<iostream>

using namespace std;


void solve(){
	int a, b, c, d;
    cin >> a >> b >> c >> d;
    int hair_length = a;
    int cnt = 0;
    for(int i=2; i<=d; i++){
        hair_length += b;
        if(hair_length>=c){ 
            hair_length = a; 
            cnt++;
        }
    }
    cout << cnt << endl;
}

int main(){
	int T;
	cin >> T;
	for(int i=1; i<=T; i++){
		cout << "Case #"<<i<<":"<<endl;
		solve();
	}
    return 0;
}