#!usr/local/bin/python3


def solve():
	A, B, C, D = map(int, input.split(' '))
	hair_len = A
	cut_count = 0
	for i in range(2,D+1):
		hair_len += B
		if hair_len >= C:
			hair_len = A
			cut_count += 1
	print(cut_count)

T = int(input())
for i in range(T):
	print('Case #{}:'.format(i+1))
	solve()