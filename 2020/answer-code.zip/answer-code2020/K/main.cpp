#include <iostream>
#include <vector>

using namespace std;

struct Doubling {
    const int LOG;
    vector<vector<int>> table;
    int A, B, C;

    Doubling(int sz, int64_t lim_t, int a, int b, int c) : LOG(64 - __builtin_clzll(lim_t)) {
        table.assign(LOG, vector<int>(sz, -1));
        A = a;
        B = b;
        C = c;
    }

    void set_next(int k) {
        if (k % A == 0) {
            table[0][k] = k / A;
        } else {
            table[0][k] = (k * B + C >= table[0].size()) ? -1 : k * B + C;
        }
    }

    void build() {
        for (int k = 0; k + 1 < LOG; k++) {
            for (int i = 0; i < table[k].size(); i++) {
                if (table[k][i] == -1) table[k + 1][i] = -1;
                else table[k + 1][i] = table[k][table[k][i]];
            }
        }
    }

    int query(int k, int64_t t) {
        for (int i = LOG - 1; i >= 0; i--) {
            if ((t >> i) & 1) {
                k = table[i][k];
                if (k < 0) return k;
            }
        }
        return k;
    }
};

void solve() {
    int N, L;
    cin >> N >> L;
    int A, B, C;
    cin >> A >> B >> C;

    Doubling d(L + 1, 1e18, A, B, C);
    for (int i = 0; i < L + 1; ++i) {
        d.set_next(i);
    }
    d.build();

    while (N--) {
        int x;
        int64_t p;
        cin >> x >> p;
        cout << d.query(x, p) << endl;
    }
}

signed main() {

    int T;
    cin >> T;
    for (int i = 0; i < T; ++i) {
        cout << "Case #" << i + 1 << ":" << endl;
        solve();
    }

    return 0;
}
