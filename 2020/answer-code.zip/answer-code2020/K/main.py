#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
    result = 0
    N, L = map(int, raw_input().split())
    A, B, C = map(int, raw_input().split())
    MAX_P = int(1e18)

    log_MAX_P = MAX_P.bit_length()
    doubling = [[-1 for _ in range(L + 1)] for _ in range(log_MAX_P)]

    for i in range(L + 1):
        if i % A == 0:
            doubling[0][i] = i / A
        else:
            doubling[0][i] = i * B + C
            if doubling[0][i] >= L:
                doubling[0][i] = -1

    for i in range(1, log_MAX_P):
        for j in range(L + 1):
            if doubling[i - 1][j] == -1:
                doubling[i][j] = -1
            else:
                doubling[i][j] = doubling[i - 1][doubling[i - 1][j]]

    for _ in range(N):
        X, P = map(int, raw_input().split())
        P_bin = list(map(int, [list(bin(P))[-i] for i in range(1, P.bit_length() + 1)]))
        for i in range(P.bit_length()):
            if P_bin[i]:
                X = doubling[i][X]

        print X


if __name__ == "__main__":
    N = int(input())
    for i in range(N):
        print "Case #" + str(i + 1) + ":"
        solve()
