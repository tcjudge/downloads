#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
	m = int(input())
	s_list = [list(raw_input().split()) for _ in range(m)]
	n = int(input())
	t_list = [list(raw_input().split()) for _ in range(n)]

	s_day_list = []
	t_day_list = []

	for i in range(m):
		s_person_list = s_list[i]
		s_day_list.extend(s_person_list[1:])
	for i in range(n):
		t_person_list = t_list[i]
		t_day_list.extend(t_person_list[1:])

	s_ok_count = {}
	for day in s_day_list:
		if day in s_ok_count:
			s_ok_count[day] = s_ok_count[day] + 1
		else:
			s_ok_count[day] = 1

	s_all_ok = {}
	for k, v in s_ok_count.items():
		if v == m:
			s_all_ok[k] = v

	for day in t_day_list:
		if day in s_all_ok:
			s_all_ok[day] = s_all_ok[day] + 1
		else:
			s_all_ok[day] = 1

	max_day_list = [kv[0] for kv in s_all_ok.items() if kv[1] == max(s_all_ok.values())]
	replace_list = [int(d.replace('/', '')) for d in max_day_list]

	result_day = str(min(replace_list))[:4] + '/' + str(min(replace_list))[4:6] + '/' + str(min(replace_list))[6:]
	result = result_day + ' ' + str(s_all_ok[result_day])

	return result

if __name__ == "__main__":
	T = int(input())
	for i in range(T):
		print "Case #" + str(i+1) + ":"
		print solve()
