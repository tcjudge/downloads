#include<iostream>
#include<string>
#include<map>

using namespace std;

string remove(string input)
{
  input.erase(std::remove(input.begin(),input.end(),'/'),input.end());
  return input;
}

void solve() {
  int m, n;
  cin >> m;
  int a;
  map<string, int> mp1;
  string a_day;
  for(int i=0; i<m; i++){
    cin >> a;
    for(int j=0; j<a; j++){
      cin >> a_day;
      if(mp1.count(a_day)==0){
        mp1[a_day] = 1;
      }
      else { mp1[a_day] = mp1[a_day] + 1; }
    }
  }

  map<string, int> mp2;
  for(auto d: mp1){
    if(d.second==m){
      mp2.insert(make_pair(d.first,d.second));
    }
  }
  //在校生
  cin >> n;
  int b;

  for(int i=0; i<n; i++){
    cin >> b;
    for(int j=0; j<b; j++){
      cin >> a_day;
      if(mp2.count(a_day)!=0){
        mp2[a_day] = mp2[a_day]+1;
      }
    }
  }
  int max = m;
  a_day = mp2.begin()->first;
  for(auto d: mp2){
    if(d.second>max){
      a_day = d.first;
      max = d.second;
    }
  }
  cout << a_day << " " << max << endl;
}

int main(void) {
	int t;
	cin >> t;
	for (int i = 1; i <= t; ++i) {
		cout << "Case #" << i << ":" << endl;
		solve();
	}
	return 0;
}
