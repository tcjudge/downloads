#!/usr/bin/python3
def test():
    N = int(input())
    n = list(map(int,input().split(' ')))
    i = int(input())
    j = int(input())
    primes =[]
    for _ in range(i+1):
        primes.append(True)

    primes[0]=True
    primes[1]=True

    for a in n:
        for b in range(a,i+1,a):
            primes[b] = False

    counter = 1
    for a in range(i,0,-1):
        if primes[a]:
            if counter == j :
                print(a)
                return 
            else:
                counter+=1
    print (-1)
    

t = int(input())
for i in range(t):
    print('Case #{}:'.format(i+1))
    test()