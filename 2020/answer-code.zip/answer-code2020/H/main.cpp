#include<iostream>
#include<vector>

using namespace std;

int a_fun(){
	int N;
	cin >> N;
	vector<int> n;
	int num;
	for(int a=0; a<N; a++){
		cin >> num;
		n.push_back(num);
	}
	int i;
	cin >> i;
	int j;
	cin >> j;

	// solve
	int flag;
	int cnt = 0;
	for(int a=i; a>=1; a--){
		flag = 0;
		for(auto item: n){
			if(a%item==0) {
				flag = 1;
				break;
			}
		}
		if(flag!=1) cnt++;
		if(cnt==j){
			cout << a << endl;
			return 0; //Tあるときはここ変える
		}
	}
	cout << -1 << endl;
	return 0;
}

int main(){
    int a;
    std::cin >> a;
    for (int i =0; i < a; i++){
        cout<< "Case #"<< i+1 << ":"<<endl;
        a_fun();
    }
}