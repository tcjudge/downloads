#include <stdio.h>
#include <stdlib.h>

void solve() {
    int U, V;
    scanf("%d", &U);
    scanf("%d", &V);

    int ans = 0;

    for (int i = 0; i < 4; ++i) {
        int u = U % 10;
        int v = V % 10;
        int diff = abs(u - v);
        if (diff >= 6) diff = 10 - diff;

        ans += diff;

        U /= 10;
        V /= 10;
    }

    printf("%d\n", ans);
}

signed main() {

    // solve();

    int T;
    scanf("%d", &T);
    for (int i = 0; i < T; ++i) {
        printf("Case #%d:\n", i + 1);
        solve();
    }

    return 0;
}