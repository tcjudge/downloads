#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
    U = raw_input()
    V = raw_input()

    ans = 0

    for i in range(4):
        diff = abs(int(U[i]) - int(V[i]))
        if diff >= 6:
            diff = 10 - diff

        ans += diff
    
    return ans

if __name__ == "__main__":
    N = int(input())
    for i in range(N):
        print "Case #" + str(i + 1) + ":"
        print solve()

