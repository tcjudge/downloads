#include<stdio.h>
#include<stdlib.h>

void solve(){
  int n;
  scanf("%d\n", &n);

  int total = 0;
  for(int i = 0; i < n; i++){
    int price;
    scanf("%d", &price);
    total += price;
  }

  if(total > 50000){
    printf("Many\n");
  }else if(total < 50000){
    printf("Few\n");
  }else{
    printf("Equal\n");
  }
}

int main(){
  int t;
  scanf("%d\n", &t);
  for(int i = 1; i <= t; i++){
    printf("Case #%d:\n", i);
    solve();
  }
  return 0;
}
