#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
	N = int(input())
	price = list(map(int, raw_input().split()))

	total = sum(price)

	if total > 50000:
		return "Many"
	elif total < 50000:
		return "Few"
	else:
		return "Equal"

if __name__ == "__main__":
	T = int(input())
	for i in range(T):
		print "Case #" + str(i+1) + ":"
		print solve()
