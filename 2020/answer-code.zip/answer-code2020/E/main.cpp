#include<iostream>

using namespace std;

int is_prime(int N){
    /* 0を返したとき素数，1を返したとき素数でない*/
    if(N%2==0){ return 1; }
    else {
        for(int i=3; i<N; i+=2){
            if(N%i==0) { return 1;}
        }
        return 0;
    }
}

int a_fun(){
    int n;
    int i;
    cin >> n >> i;
    int prime_cnt = 0;
    for(int num=n; num>=2; num--){
        if(is_prime(num)==0) prime_cnt++;
        if(prime_cnt==i) {
            cout << num << endl;
            return 0;
        }
    }
    return 0;  
}

int main(){
    int a;
    std::cin >> a;
    for (int i =0; i < a; i++){
        cout<< "Case #"<< i+1 << ":"<<endl;
        a_fun();
    }
}