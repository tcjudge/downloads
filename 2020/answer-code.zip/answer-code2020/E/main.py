#!/usr/bin/python3
def test():
    n = int(input())
    i = int(input())
    primes =[]
    for j in range(n+1):
        primes.append(True)

    primes[0]=False
    primes[1]=False

    for j in range(n+1):
        if primes[j]:
            for x in range(j*2,n+1,j):
                primes[x] = False
    counter = 1
    for j in range(n,0,-1):
        if primes[j]:
            if counter == i :
                print(j)
                return
            else:
                counter+=1

t = int(input())
for i in range(t):
    print('Case #{}:'.format(i+1))
    test()
    
