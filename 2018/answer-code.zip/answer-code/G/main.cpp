#include<iostream>
#include<vector>
using namespace std;

string solve(int n, int sum, vector<int> v) {
    vector<vector<bool> > dp(n+1, vector<bool>(sum + 1, false));

    // i軒目までに, お菓子をj個持っている可能性があるかどうかを考えて行く
    dp[0][0] = true;
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= sum; j++) {
            // お菓子の個数が，一つ前の家で貰えると個数より小さい
            // つまり，絶対にお菓子を貰わない場合だけあり得る
            if (j < v[i -1]) {
                dp[i][j] = dp[i - 1][j];
            }
            // そうでないなら，お菓子を貰う時と貰わない時が有りうる
            else {
                dp[i][j] = dp[i - 1][j] || dp[i - 1][j - v[i-1]];
            }
        }
    }

    // 合計を計算
    int ans = 0;
    for (int i = 0; i <= sum; i++) {
        if (dp[n][i])
            ans += i;
    }

    return to_string(ans);
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        int N; cin >> N;
        int sum = 0;
        vector<int> v = vector<int>();
        for (int i = 0; i < N; i++) {
            int a; cin >> a;
            sum += a;
            v.push_back(a);
        }
        cout << solve(N, sum, v) << endl;
    }
    return 0;
}
