#include <iostream>
#include <vector>
using namespace std;

int solve(string P, int n) {
    // aからbまで区間の中でいくつ消すことができるかを保持する
    vector<vector<int> > dp(n+1, vector<int>(n+1, 0));

    // 注目する区間を少しずつ大きくする
    for (int w = 3; w <= n ; w++) {

        // どこから注目するか(左端)
        for (int l = 0; l <= n; l++) {
            int r = l + w - 1;  // 右端
            if (r >= n) continue;

            // 区間での最高得点を更新
            for (int c = l; c < r; c++) {
                dp[l][r] = max(dp[l][r], dp[l][c] + dp[c + 1][r]);
            }

            // 両端が1で，
            if (P[l] == '1' && P[r] == '1') {
                // その間のcが0で，rcl以外が全て消せるなら区間rcは全て消せる
                for (int c = l + 1; c < r; c++) {
                    if (P[c] == '0' && dp[l+1][c-1] + dp[c+1][r-1] == w-3) 
                        dp[l][r] = w;
                }
            }
        }
    }
    return dp[0][n-1] / 3;
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        int n; cin >> n;
        string P; cin >> P;
        cout << solve(P, n) << endl;
    }
    return 0;
}
