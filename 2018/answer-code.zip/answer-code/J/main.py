#!/usr/bin/python
# coding: utf-8

LEG = "1"
BODY = "0"
ROBOT = LEG + BODY + LEG

is_robot = lambda x: True if "".join(x) == ROBOT else False

def run(num_of_parts, parts):
    table = [[0 for _ in xrange(num_of_parts)] for _ in xrange(num_of_parts)]

    # 長さ3の101の列を見る
    for i in xrange(0, num_of_parts-2):
        if is_robot(parts[i:i+3]):
            table[i][i+2] = 3

    # 長さ4以上の列を見る
    for length in xrange(3, num_of_parts):
        for left in xrange(0, num_of_parts-length):
            right = left + length
            for mid in xrange(left, right):
                table[left][right] = max(table[left][right], table[left][mid]+table[mid+1][right])

            inner_left = left + 1
            inner_right = right - 1
            if not (table[inner_left][inner_right] == (inner_right - inner_left)) or not (parts[left] == parts[right] == LEG):
                continue
            body_counter = 0
            for mid in xrange(inner_left, inner_right+1):
                if parts[mid] == BODY:
                    body_counter += 1
            if ((inner_right - inner_left) / 3) + 1 == body_counter:
                table[left][right] = length + 1

    print table[0][num_of_parts-1] / 3


if __name__ == "__main__":
    for i in range(int(input())):
        print "Case #" + str(i+1) + ":"
        run(input(), list(raw_input()))
