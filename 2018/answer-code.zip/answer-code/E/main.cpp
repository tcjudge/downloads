#include<iostream>
#include<stack>
#include<string>
#include<cctype>
using namespace std;
int solve(string m) {
    stack<int> s;
    for(int i = 0; i < m.size(); i++) {
        char c = m[i];
        // 数字なら
        if (isdigit(static_cast<unsigned char>(c))) {
            s.push(c - '0');
        } else {
            int b = s.top();
            s.pop();
            int a = s.top();
            s.pop();
            int ans;
            if (c == '&') {
                ans = a & b;
            } else if (c == '|') {
                ans = a | b;
            } else if (c == '^') {
                ans = a ^ b;
            } else if (c == '<') {
                ans = a << b;
                i++;
            } else if (c == '>') {
                ans = a >> b;
                i++;
            }
            s.push(ans);
        }
    }
    return s.top();
}
int main(void) {
    int T; cin >> T;
    for (int i = 1; i <=T; i++) {
        cout << "Case #" << i << ":" << endl;
        string m; cin >> m;
        cout << solve(m) << endl;
    }
    return 0;
}
