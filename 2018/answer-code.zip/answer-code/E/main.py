#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

def RPN(states, verbose=False):
    '''
    逆ポーランド記法を計算する関数
    '''
    operator = {
        '&': (lambda x, y: x & y),
        '|': (lambda x, y: x | y),
        '^': (lambda x, y: x ^ y),
        '<': (lambda x, y: x << y),
        '>': (lambda x, y: x >> y)
    }
    states = states.replace('<<', '<')
    states = states.replace('>>', '>')
    
    stack = []
    if verbose: print('RPN: %s' % states)
    for z in states:
        if z not in operator.keys():
            stack.append(int(z))
        else:
            y = stack.pop()
            x = stack.pop()
            stack.append(operator[z](x, y))
            if verbose: print('%s %s %s =' % (x, z, y))
        if verbose: print(stack)
    if verbose: print(stack[0])
    return stack[0]

if __name__ == '__main__':
    # for python2
    for i in range(int(input())):
        print "Case #" + str(i+1) + ":"
        print(RPN(raw_input(), verbose=False))
    #RPN("34^12&<<".split(" "), verbose=True)
    # for python3
    #print(RPN(input(), verbose=False))
    # for debug
    #RPN("34^12&<<".split(" "), verbose=True)
