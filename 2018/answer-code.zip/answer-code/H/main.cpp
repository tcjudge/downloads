#include <iostream>
#include <vector>
using namespace std;

int W, H;
vector<string> v(10, "N");
int black = 0, white = 0;

void calcScore(int top, int bot, int lef, int rig, char color) {
    int score = 0;
    for (int i = top+1; i < bot; i++) {
        for (int j = lef+1; j < rig; j++) {
            if (v[i][j] != color) {
                score++;
            }
        }
    }
    if (color == 'B')
        black = max(black, score);
    else
        white = max(white, score);
}

void serchBottom(int top, int lef, int rig, char color) {
    for (int bot = H-1; bot > top; bot--) {
        if ((v[bot][lef] == color) && (v[bot][rig] == color)) {
            calcScore(top, bot, lef, rig, color);
            break;
        }
    }
}

void serchRight(int top, int lef, char color) {
    for (int rig = W-1; rig > lef; rig--) {
        if (v[top][rig] == color) {
            serchBottom(top, lef, rig, color);
        }
    }
}


void serchLeft() {
    for (int top = 0; top < H; top++) {
        for (int lef = 0; lef < W; lef++) {
            serchRight(top, lef, v[top][lef]);
        }
    }
}

string solve() {
    serchLeft();

    string ans = "";
    if (black > white)
        ans = "B " + to_string(black);
    else if (black < white)
        ans = "W " + to_string(white);
    else
        ans = "DRAW";

    return ans;
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        black = white = 0;
        cout << "Case #" << t << ":" << endl;
        cin >> W >> H;
        for (int i = 0; i < H; i++) {
            cin >> v[i];
        }
        cout << solve() << endl;
    }
    return 0;
}
