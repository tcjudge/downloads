import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	BufferedReader reader;
	int bScore;
	int wScore;

	public Main() {
		reader = new BufferedReader(new InputStreamReader(System.in));
		bScore = wScore = 0;
	}

	public void run() {
		char[][] board = null;
		try {
			board = makeBoard(); // 盤面生成
			putStone(board); // 盤面への石配置
		} catch (IOException e) {
			e.printStackTrace();
		}

		calculateScore(board); //スコア計算
		outResult(); // 結果の出力
		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Main jadger = new Main();
		jadger.run();
	}

	private char[][] makeBoard() throws IOException {
		String[] size = reader.readLine().split(" ");

		int width = Integer.parseInt(size[0]);
		int height = Integer.parseInt(size[1]);

		return new char[height][width];
	}

	private void putStone(char[][] board) throws IOException {
		for (int y = 0; y < board.length; y++) {
			char[] colStone = reader.readLine().toCharArray();

			board[y] = colStone;
		}
	}

	private void calculateScore(char[][] board) {
		int h = board.length;
		int w = board[0].length;


		for (int ay = 0; ay < h; ay++) {
			for (int ax = 0; ax < w; ax++) {
				for (int by = ay + 2; by < h; by++) {
					for (int bx = ax + 2; bx < w; bx++) {
						if (board[ay][ax] == board[by][bx] && board[ay][bx] == board[by][ax] && board[ay][bx] == board[by][bx]) {
							char target = board[ay][ax];
							int score = calculateScore(ax, ay, bx - ax,by - ay, board, target);
							if ('B' == target)
								bScore = Math.max(bScore, score);
							else
								wScore = Math.max(wScore, score);
						}
					}
				}
			}
		}

	}

	private int calculateScore(int stX, int stY, int width, int height, char[][] board, char target) {
		int score = 0;
		for (int y = stY + 1; y < (stY + height); y++) {
			for (int x = stX + 1; x < (stX + width); x++) {
				if (board[y][x] != target)
					score++;
			}
		}
		return score;
	}

	private void outResult() {
		StringBuilder result = new StringBuilder();
		if (bScore == wScore) {
			result.append("DRAW");
		} else if (bScore > wScore) {
			result.append("B");
			result.append(" ");
			result.append(bScore);
		} else {
			result.append("W");
			result.append(" ");
			result.append(wScore);
		}
		System.out.println(result.toString());
	}

}
