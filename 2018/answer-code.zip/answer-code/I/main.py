#!/usr/bin/python
# coding: utf-8
from math import cos, sin, radians, sqrt

g = -9.8

# バットの初速をv1, ボールの初速をv2とし，
# インパクト後のバットの速度をv1d, ボールの速度をv2dとする．
# また，バットの質量をm1, ボールの質量をm2とすると，
# m1 * v1 + m2 * v2 = m1 * v1d + m2 * v2d が成り立つ（運動量保存の法則）．
# m1 = 6.0, m2 = 1.0 より，6.0 * v1 + v2 = 6.0 * v1d + v2d となる (1)．
# また，弾性衝突なので，v1 - v2 = v2d - v1d が成り立つ (2)．
# (1)及び(2), 与えられるv1, v2により，インパクト後のバット及びボールの速度がわかる．
def calc_velocities(v1, v2):
    # (2) より，v2d = v1 + v1d - v2 (3)
    # これを(1) に当てはめると，
    # 6.0 * v1 + v2 = 6.0 * v1d + (v1 + v1d - v2)
    # よって，v1d = (2.0 * v2 + 5.0 * v1) / 7.0
    v1d = (2.0 * v2 + 5.0 * v1) / 7.0
    v2d = v1 + v1d - v2 # (3)
    return v1d, v2d

def run(v1, v2, theta):
    v1d, v2d = calc_velocities(v1, v2)
    # print v2d
    theta = radians(theta*2)
    x2 = v2d * cos(theta)
    y2 = v2d * sin(theta)
    # print x2, y2
    t = 2*y2/-g
    # print t
    # print t * x2
    print "OK" if t*x2 >= 98 else "NG"

if __name__ == "__main__":
    for i in range(int(input())):
        print "Case #" + str(i+1) + ":"
        run(*map(float, raw_input().split()))
