#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#include<iostream>
#include<string>

float G = 9.8f;
float m = 1.0f;
float M = 6.0f;

float degToRad(float deg) {
    float rad = 0.0f;
    rad = deg / 180.0f * M_PI;
    return rad;
}

float calc_x(float v, float rad) {
    float x = 0.0f;
    x = v * fabs(cosf(rad));
    return x;
}

float calc_y(float v, float rad) {
    float y = 0.0f;
    y = v * fabs(sinf(rad));
    return y;
}


void run(float S, float B, float deg) {
    float v;
    v = ((m-M)*B+2.0f*M*S) / (m+M);
    float rad = degToRad(2.0f*deg);
    float x = calc_x(v, rad);
    float y = calc_y(v, rad);
    float max_t = 2 * (y / G);
    float nec_t;

    if(x>0) {
        nec_t = 98.0f / x;
    }
    else {
        nec_t = 1000000.0f;
    }


    if(max_t < nec_t && nec_t >= 0) {
        std::cout << "NG" << std::endl;
        return;
    }
    else {
        std::cout << "OK" << std::endl;
        return;
    }

}

int main(void) {
    int T = 0;
    // バット速度
    float S = 0.0f;
    // ボール速度
    float B = 0.0f;
    float deg = 0.0f;

    std::cin >> T;
    for(int i=1;i<=T;i++) {
        S = 0.0f;
        B = 0.0f;
        deg = 0.0f;

        std::cin >> S;
        std::cin >> B;
        std::cin >> deg;
        std::cout << "Case #" << std::to_string(i) << ":" <<std::endl;
        run((float)S, (float)B, (float)deg);
    }
}

