#include <stdio.h>

void run() {
    int A, B;
    scanf("%d %d", &A, &B);

    if(A < B) {
        int temp = A;
        A = B;
        B = temp;
    }

    int x = A * B;
    int r = A % B;
    while(r != 0) {
        A = B;
        B = r;
        r = A % B;
    }
    printf("%d\n", x / B);
}

int main() {
    int T;
    scanf("%d", &T);
    for(int i = 0; i < T; i++) {
        printf("Case #%d:\n", i+1);
        run();
    }
}
