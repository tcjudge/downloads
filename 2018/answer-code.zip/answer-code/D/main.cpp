#include<iostream>
using namespace std;

// 最大公約数を求める
int GCD(int a, int b) {
    if (a < b) {
        int tmp = a;
        a = b;
        b = tmp;
    }

    int r = a % b;
    while(r != 0) {
        a = b;
        b = r;
        r = a % b;
    }

    return b;
}

string solve(int a, int b) {
    int lcm = (a * b) / GCD(a, b);
    return to_string(lcm);
}
int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        int A, B;
        cin >> A >> B;
        cout << solve(A, B) << endl;
    }
    return 0;
}
