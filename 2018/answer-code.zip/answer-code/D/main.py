#!/usr/bin/python
# coding: utf-8

def run(a, b):
	count_a = 1
	count_b = 1

	while count_a * a != count_b * b:
		if count_a * a < count_b * b:
			count_a += 1
		else:
			count_b += 1
	
	print(count_a * a)

if __name__ == "__main__":
    for i in range(int(input())):
        print "Case #" + str(i+1) + ":"
        run(*map(int, raw_input().split()))
