#!/usr/bin/python
# Python2

t = input()

for ti in range(t):
    print('Case #{0}:'.format(ti + 1))
    n = input()

    input_list = list(map(int, raw_input().split()))

    result_list = []


    def solve(current_position, sum_num=0):
        if current_position == len(input_list): # isFinish?
            result_list.append(sum_num)
        else:
            next_position = current_position + 1

            # payment
            solve(next_position, sum_num + input_list[current_position])

            # none
            solve(next_position, sum_num)


    solve(0)

    print(sum(list(set(result_list))))
