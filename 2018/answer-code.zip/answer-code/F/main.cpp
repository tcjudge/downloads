#include<iostream>
#include<vector>
#include<set>
#include<numeric>
using namespace std;

// お菓子の個数の種類
set<int> sums;
// 各家がお菓子をくれる個数
vector<int> v = vector<int>();

void run(int sweetsNum, int houseId) {
    if (houseId == (int)v.size()) {
        sums.insert(sweetsNum);
    } else {
        // 貰う場合
        run(sweetsNum + v[houseId], houseId+1);
        // 貰わない場合
        run(sweetsNum, houseId+1);
    }
}

string solve(int sum, vector<int> v) {
    run(0, 0);
    return to_string(accumulate(sums.begin(), sums.end(), 0));
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        sums.clear();
        v.clear();
        cout << "Case #" << t << ":" << endl;
        int N; cin >> N;
        int sum = 0;
        for (int i = 0; i < N; i++) {
            int a; cin >> a;
            sum += a;
            v.push_back(a);
        }
        cout << solve(sum, v) << endl;
    }
    return 0;
}
