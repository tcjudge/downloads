#include<iostream>
#include<vector>
using namespace std;
 
string solve(int N) {
    int cost = 0;
    cost += (N / 24) * 1000;
    cost += min(1000, (N % 24) * 100);
    return to_string(cost);
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        int N; cin >> N;
        cout << solve(N) << endl;
    }
    return 0;
}
