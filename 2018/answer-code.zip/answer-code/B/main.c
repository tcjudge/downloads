#include <stdio.h>

void run() {
    int N;
    scanf("%d", &N);
	int days = N / 24;
	int hours = N % 24;
	int fee = (1000 * days);
	if (hours >= 10) {
		fee += 1000;
	} else {
		fee += 100 * hours;
	}
	printf("%d\n", fee);
}

int main() {
    int T;
    scanf("%d", &T);
    for(int i = 0; i < T; i++) {
        printf("Case #%d:\n", i+1);
        run();
    }
}
