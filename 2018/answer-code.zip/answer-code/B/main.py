#!/usr/bin/python
# coding: utf-8

def run(n):
    day = n / 24
    time = (n % 24) if (n % 24) < 10 else 10
    print day * 1000 + time * 100

if __name__ == "__main__":
    for i in range(int(input())):
        print "Case #" + str(i+1) + ":"
        run(input())
