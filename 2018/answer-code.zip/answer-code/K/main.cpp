#include <iostream>
#include <vector>
#define MAXIMUM 1<<27
using namespace std;

int E, V;
vector<vector<int> > g(1000, vector<int>(1000, MAXIMUM));

int run(int node, int cost, vector<bool> &used) {
    if (node == V-1) {
        return cost;
    }

    used[node] = true;

    for (int i = 0; i < V; i++) {
        int c = g[node][i];
        if (used[i] || c == MAXIMUM || c == 0)
            continue;

        int result = run(i, min(cost, g[node][i]), used);
        if (result > 0) {
            g[node][i] -= result;
            g[i][node] += result;
            return result;
        }
    }
    return 0;
}

int solve(vector<vector<int> > &g) { 
    int min = 0;
    int cost;
    do {
        vector<bool> used(V, false);
        cost = run(0, MAXIMUM, used);
        min += cost;
    } while(cost != 0);
    return min;
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        vector<vector<int> > g2(1000, vector<int>(1000, MAXIMUM));
        g = g2;
        // input
        cin >> E >> V;
        for (int i = 0; i < E; i++) {
            int v, u, c; cin >> v >> u >> c;
            g[v][u] = c;
            g[u][v] = 0;
        }

        cout << solve(g) << endl;
    }
    return 0;
}
