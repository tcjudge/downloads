#!/usr/bin/python
# coding: utf-8

from collections import defaultdict

MAX_COST = float("inf")
rivers = None
visited = list()

def route_and_cost(_from, city, min_cost):
    if _from == city:
        return min_cost
    for to, cost in rivers[_from].items():
        if visited[to] or cost == 0:
            continue
        visited[to] = True
        cost = route_and_cost(to, city, min(min_cost, cost))
        if cost > 0:
            rivers[_from][to] -= cost
            rivers[to][_from] += cost
            return cost
    return 0

def input_velues():
    global rivers
    n, m = map(int, raw_input().split())
    rivers = defaultdict(dict)
    for _ in xrange(n):
        s, e, c = map(int, raw_input().split())
        rivers[s][e] = c
        rivers[e][s] = 0
    return n, m

def run():
    global visited
    n, m = input_velues()
    lake = 0
    city = m-1
    answer = 0
    while True:
        visited = [False for i in xrange(m)]
        visited[0] = True
        cost = route_and_cost(_from=lake, city=city, min_cost=MAX_COST)
        if cost == 0:
            break
        answer += cost
    print answer

if __name__ == "__main__":
    for i in xrange(input()):
        print "Case #%d:" % (i+1)
        run()
