#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve():
	year = int(input())
	
	if year <= 2007 or year >= 2019:
		return "NG"
	elif year == 2018:
		return "ISE"
	else:
		return "CSE"

if __name__ == "__main__":
	for i in range(int(input())):
		print "Case #" + str(i+1) + ":"
		print solve()
