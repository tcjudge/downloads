#include<iostream>
using namespace std;
string solve(int n) {
    if (n == 2018) {
        return "ISE";
    } else if (2008 <= n && n < 2018) {
        return "CSE";
    }
    return "NG";
}

int main(void) {
    int T; cin >> T;
    for (int i = 1; i <= T; i++) {
        cout << "Case #" << i << ":" << endl;
        int N; cin >> N;
        cout << solve(N) << endl;
    }
    return 0;
}
