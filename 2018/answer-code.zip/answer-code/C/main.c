#include<stdio.h>
#include<string.h>

int main(void) {
  int t;
  scanf("%d", &t);

  for (int ti = 0; ti < t; ti++) {
    printf("Case #%d:\n", ti + 1);

    // input s, m, l
    char s[30], m[30], l[30];
    scanf("%s %s %s", s, m, l);

    // calculate length of s, m, l
    int slen = strlen(s);
    int mlen = strlen(m);
    int llen = strlen(l);

    if (slen == 5 && mlen == 7 && llen == 5) { // 5.7.5
      printf("%s %s %s\n", s, m, l);
    } else if (slen + mlen + llen > 17) { // over
      for (int i = 0; i < 5; i++) {
        printf("%c", s[i]);
      }
      printf(" ");

      for (int i = 0; i < 7; i++) {
        printf("%c", m[i]);
      }
      printf(" ");

      for (int i = 0; i < 5; i++) {
        printf("%c", l[i]);
      }
      printf("\n");
    } else { // under
      printf("NG\n");
    }
  }

  return 0;
}
