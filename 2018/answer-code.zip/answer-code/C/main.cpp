#include<iostream>
using namespace std;

int haiku[3] = {5, 7, 5};

string solve() {
    string str[3];
    cin >> str[0] >> str[1] >> str[2];
    
    string out = "";
    for (int i = 0; i < 3; i++) {

        // 文字数が足りない
        if (str[i].size() < haiku[i]) {
            return "NG";
        }

        for (int s = 0; s < haiku[i]; s++) {
            out += str[i][s];
        }
        if (i != 2)
            out += ' ';
    }

    return out;
}

int main(void) {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":" << endl;
        cout << solve() << endl;
    }
    return 0;
}
