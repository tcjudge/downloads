import java.util.*;

class Main {
  void run() {
    Scanner sc = new Scanner(System.in);

    int T = sc.nextInt();
    for(int i = 1; i <= T; i++){
      System.out.println("Case #" + i + ":");

      String a = sc.next();
      String b = sc.next();
      String c = sc.next();

      if(a.length() < 5 || b.length() < 7 || c.length() < 5){
        System.out.println("NG");

      }else{
        a = a.substring(0, 5);
        b = b.substring(0, 7);
        c = c.substring(0, 5);
        System.out.println(a + " " + b + " " + c);
      }
    }
  }

  public static void main(String[] args) {
    new Main().run();
  }
}
